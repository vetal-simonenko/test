SALES VOICE AGENT — MANAGER DEMO

1. Double-click Sales-Voice-Agent-Demo.html.
2. Use the "Use sample note" option for the most reliable demonstration.
3. Follow the questions, accept or change the suggested CRM links, and save the mock CVR.
4. Open the Brief tab to view the pre-meeting workflow.

This is a frontend prototype running with deterministic mock data.
No recording or customer information is transmitted when it displays Mock mode.
Real AWS, Salesforce, Databricks, Outlook, and Entra ID services are not connected.
Microphone access may be restricted when the file is opened directly from disk.
