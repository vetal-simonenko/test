import type { CustomerBrief, EntityResolutionItem, MeetingSummary, Opportunity, PipelineStatus, VoiceProcessingResult } from './types'

const delay = (ms = 650) => new Promise((resolve) => window.setTimeout(resolve, ms))

export const opportunities: Opportunity[] = [
  { id: 'opp-101', name: 'Chevron Asset Performance Management', value: '$1.2M', stage: 'Proposal' },
  { id: 'opp-102', name: 'Enterprise Systems Integration', value: '$1.1M', stage: 'Qualification' },
]

export const sampleTranscript =
  "Met with Brian from Chevron today to discuss asset performance management. He was interested but had questions about implementation timelines and system integration. I'll send pricing and customer references, and we'll schedule a technical workshop next month."

export async function processVoiceNote(_audio?: Blob): Promise<VoiceProcessingResult> {
  await delay(900)
  return {
    transcript: sampleTranscript,
    questions: [
      { id: 'q1', topic: 'Customer challenge', prompt: 'What customer challenge or business goal seemed most important to Brian?' },
    ],
    summary: {
      customer: 'Chevron',
      opportunityId: 'opp-101',
      opportunity: 'Chevron Asset Performance Management',
      sentiment: 'Positive',
      participants: 'Mariah Smith; Brian, Chevron',
      products: 'Asset Performance Management',
      dealSignals: 'Customer requested pricing, references and a technical workshop',
      decisionMakers: 'Brian and Chevron operations stakeholders',
      statedNeeds: 'Reduce unplanned downtime and improve equipment reliability across multiple sites',
      timeline: 'Technical workshop next month',
      objections: 'Questions about implementation timelines and system integration',
      actionItems: 'Send pricing and customer references; schedule a technical workshop',
      blockers: 'Integration scope needs validation',
      competitors: '',
      competitorStrengths: '',
      competitorWeaknesses: '',
      decisionProcess: 'Technical validation before commercial approval',
      procurementConstraints: '',
      incumbentFootprint: '',
      nextCommitment: 'Schedule a technical workshop next month',
      summary: 'Chevron is evaluating asset performance management to reduce downtime and improve equipment reliability. The next step is to share pricing and customer references, then align a technical workshop.',
    },
  }
}

export async function resolveEntities(summary: MeetingSummary): Promise<EntityResolutionItem[]> {
  await delay(450)
  return [
    {
      id: 'account', kind: 'account', label: 'Customer account', originalText: summary.customer, required: true,
      selectedId: 'acc-001', action: 'pending',
      candidates: [
        { id: 'acc-001', label: 'Chevron Corporation', detail: 'CRM Account · Global', matchMethod: 'Exact normalized name', confidence: 96, sourceSystem: 'Salesforce CRM' },
        { id: 'acc-014', label: 'Chevron U.S.A. Inc.', detail: 'CRM Account · United States', matchMethod: 'Account hierarchy match', confidence: 82, sourceSystem: 'Salesforce CRM' },
      ],
    },
    {
      id: 'opportunity', kind: 'opportunity', label: 'Opportunity', originalText: summary.opportunity, required: false,
      selectedId: summary.opportunityId, action: 'pending',
      candidates: opportunities.map((item, index) => ({ id: item.id, label: item.name, detail: `${item.stage} · ${item.value}`, matchMethod: index ? 'Account + product fuzzy match' : 'Product line match', confidence: index ? 74 : 61, sourceSystem: 'Salesforce CRM' })),
    },
    {
      id: 'participant-sales', kind: 'participant', label: 'Participant', originalText: 'Mariah Smith', required: false,
      selectedId: 'usr-118', action: 'pending',
      candidates: [{ id: 'usr-118', label: 'Mariah Smith', detail: 'Internal user · Sales', matchMethod: 'Authenticated user ID', confidence: 100, sourceSystem: 'Microsoft Entra ID' }],
    },
    {
      id: 'participant-customer', kind: 'participant', label: 'Participant', originalText: 'Brian', required: false,
      selectedId: 'con-340', action: 'pending',
      candidates: [{ id: 'con-340', label: 'Brian Carter', detail: 'Operations · Chevron', matchMethod: 'Name and account fuzzy match', confidence: 78, sourceSystem: 'Salesforce CRM' }],
    },
  ]
}

export async function reviseMeetingSummary(summary: MeetingSummary, instruction: string): Promise<MeetingSummary> {
  await delay(600)
  const next = { ...summary }
  const valueAfter = (pattern: RegExp) => instruction.match(pattern)?.[1]?.trim().replace(/[.]+$/, '')
  const customer = valueAfter(/(?:customer|account)\s+(?:is|to)\s+(.+)/i)
  const competitors = valueAfter(/competitors?\s+(?:are|is|to)\s+(.+)/i)
  const timeline = valueAfter(/timeline\s+(?:is|to)\s+(.+)/i)
  const commitment = valueAfter(/(?:next meeting|next milestone|next commitment)\s+(?:is|to)\s+(.+)/i)
  if (customer) next.customer = customer
  else if (competitors) next.competitors = competitors
  else if (timeline) next.timeline = timeline
  else if (commitment) next.nextCommitment = commitment
  else next.summary = `${next.summary}\nRevision requested: ${instruction.trim()}`
  return next
}

export async function saveCvr(summary: MeetingSummary, _resolution: EntityResolutionItem[] = []): Promise<{ id: string; pipeline: PipelineStatus }> {
  await delay(800)
  return {
    id: `CVR-${summary.customer.slice(0, 3).toUpperCase()}-2048`,
    pipeline: {
      bronze: { state: 'completed', chunks: 4 },
      silver: { state: 'completed', created: 12, updated: 2, rejected: 1 },
    },
  }
}

export async function generateEmail(summary: MeetingSummary): Promise<string> {
  await delay(500)
  return `Subject: Chevron asset performance management — follow-up\n\nHi team,\n\nWe had a positive discussion with Chevron about reducing unplanned downtime and improving equipment reliability across multiple sites. Brian asked about implementation timelines and system integration.\n\nNext steps:\n• Share pricing and relevant customer references.\n• Confirm technical workshop attendees and timing.\n• Validate the integration scope.\n\nOwner: CWI Sales Team\nTiming: Next month\n\nPlease add any missing context before this is shared internally.`
}

export async function reviseEmailDraft(email: string, instruction: string): Promise<string> {
  await delay(500)
  const request = instruction.trim().replace(/[.]+$/, '')
  if (/short|concise|brief/i.test(request)) {
    return `Subject: Chevron APM — next steps\n\nHi team,\n\nChevron is evaluating asset performance management to reduce downtime across multiple sites.\n\nNext steps:\n• Send pricing and references.\n• Confirm the technical workshop.\n• Validate integration scope.\n\nOwner: CWI Sales Team\nTiming: Next month`
  }
  return `${email.trim()}\n\nRequested update: ${request}.`
}

export async function generateBrief(context: string): Promise<CustomerBrief> {
  await delay(950)
  const customer = /chevron/i.test(context) ? 'Chevron' : /\bbp\b/i.test(context) ? 'bp' : 'ExxonMobil'
  return {
    customer,
    title: `Visit Preparation Note — ${customer}`,
    context: [
      'Recent discussions focused on equipment reliability, integration and upcoming field activity.',
      'Customer interest is positive, but technical proof and delivery timing remain important.',
      'A technical follow-up was requested with operations and engineering stakeholders.',
    ],
    sentiment: 'Mixed',
    stakeholders: ['Operations lead — decision influencer', 'Production engineer — technical evaluator', 'Account manager — relationship owner'],
    openItems: ['Confirm delivery timeline', 'Provide customer references', 'Align the next technical workshop'],
    opportunities,
    pricing: ['Current opportunity value: $1.1M', 'Pricing position requires validation in Genie'],
    competitor: 'Halliburton is the primary competitive threat based on recent notes.',
    pastEngagements: [
      { id: 'eng-301', date: 'Aug 10, 2026', title: 'Asset performance discovery', owner: 'Mariah Smith', outcome: 'Customer requested pricing, references and a technical workshop.' },
      { id: 'eng-284', date: 'Jul 22, 2026', title: 'Operations reliability review', owner: 'CWI Sales Team', outcome: 'Integration scope and proof points were identified as decision criteria.' },
      { id: 'eng-251', date: 'Jun 18, 2026', title: 'Account planning session', owner: 'Account Team', outcome: 'Mapped operations and engineering stakeholders for the opportunity.' },
    ],
    sources: [
      { id: 'src-1', title: `${customer} account and opportunity records`, system: 'Salesforce', updatedAt: 'Aug 18, 2026' },
      { id: 'src-2', title: 'Customer visit records and meeting notes', system: 'Databricks', updatedAt: 'Aug 17, 2026' },
      { id: 'src-3', title: 'Technical references and proposal material', system: 'SharePoint', updatedAt: 'Aug 15, 2026' },
      { id: 'src-4', title: 'Recent account-team correspondence', system: 'Outlook', updatedAt: 'Aug 14, 2026' },
    ],
  }
}

export async function answerBriefQuestion(question: string, brief: CustomerBrief): Promise<string> {
  await delay(550)
  if (/compet|threat|risk/i.test(question)) return brief.competitor
  if (/price|revenue|value/i.test(question)) return `${brief.pricing.join('. ')}.`
  if (/stakeholder|who/i.test(question)) return brief.stakeholders.join('; ')
  if (/next|action|open/i.test(question)) return `Recommended focus: ${brief.openItems.join('; ')}.`
  return `Based on the available notes and CRM context, focus the conversation on ${brief.openItems[0].toLowerCase()} and validate the customer's decision timeline.`
}
