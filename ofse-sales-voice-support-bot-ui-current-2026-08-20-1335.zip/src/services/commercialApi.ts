import { answerBriefQuestion as mockAnswer, generateBrief as mockBrief, generateEmail as mockEmail, reviseEmailDraft as mockReviseEmail } from '../mockApi'
import type { CustomerBrief, MeetingSummary } from '../types'
import { backendMode, backendUrl } from './runtimeConfig'

async function postJson<T>(path: string, body: unknown): Promise<T> {
  const response = await fetch(backendUrl(path), {
    method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  })
  if (!response.ok) throw new Error(`Backend request failed (${response.status})`)
  return response.json() as Promise<T>
}

export async function generateFollowUpEmail(summary: MeetingSummary) {
  return backendMode === 'mock' ? mockEmail(summary) : postJson<string>('/api/follow-up/draft', { summary })
}

export async function reviseFollowUpEmail(email: string, instruction: string) {
  return backendMode === 'mock' ? mockReviseEmail(email, instruction) : postJson<string>('/api/follow-up/revise', { email, instruction })
}

export async function sendFollowUpEmail(email: string, recipients: string[]): Promise<{ id: string; recipients: string[] }> {
  if (backendMode === 'mock') {
    await new Promise((resolve) => window.setTimeout(resolve, 550))
    return { id: `MSG-${Date.now().toString().slice(-6)}`, recipients }
  }
  return postJson<{ id: string; recipients: string[] }>('/api/follow-up/send', { email, recipients })
}

export async function createCustomerBrief(context: string) {
  return backendMode === 'mock' ? mockBrief(context) : postJson<CustomerBrief>('/api/briefs', { context })
}

export async function askCustomerBrief(question: string, brief: CustomerBrief) {
  return backendMode === 'mock' ? mockAnswer(question, brief) : postJson<string>('/api/briefs/questions', { question, brief })
}

export async function saveSalesFeedback(feedback: string, context: { source: 'live-chat'; customer?: string }) {
  if (backendMode === 'mock') {
    await new Promise((resolve) => window.setTimeout(resolve, 450))
    return { id: `FB-${Date.now().toString().slice(-6)}`, savedAt: new Date().toISOString() }
  }
  return postJson<{ id: string; savedAt: string }>('/api/feedback', { feedback, context })
}
