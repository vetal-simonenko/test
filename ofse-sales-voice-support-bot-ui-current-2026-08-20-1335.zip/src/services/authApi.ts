import type { AuthUser } from '../types'
import { backendMode, backendUrl } from './runtimeConfig'

const mockUser: AuthUser = {
  id: 'mock-sales-rep',
  displayName: 'Mariah Smith',
  email: 'mariah.smith@bakerhughes.com',
  initials: 'MS',
  authProvider: 'mock',
}

export async function getSessionUser(): Promise<AuthUser | null> {
  if (backendMode === 'mock') return mockUser
  const response = await fetch(backendUrl('/api/session'), { credentials: 'include' })
  if (response.status === 401) return null
  if (!response.ok) throw new Error(`Session check failed (${response.status})`)
  return response.json() as Promise<AuthUser>
}

export function startEntraLogin() {
  if (backendMode === 'mock') return
  const returnTo = `${window.location.pathname}${window.location.search}`
  window.location.assign(`${backendUrl('/auth/login')}?returnTo=${encodeURIComponent(returnTo)}`)
}

export function startLogout() {
  if (backendMode === 'mock') return
  window.location.assign(backendUrl('/auth/logout'))
}
