import { processVoiceNote, reviseMeetingSummary } from '../mockApi'
import type { MeetingSummary, VoiceProcessingResult } from '../types'
import { configuredUrl } from './runtimeConfig'

const voiceApiUrl = configuredUrl(import.meta.env.VITE_VOICE_API_URL, '/api/voice/process')
const revisionApiUrl = configuredUrl(import.meta.env.VITE_SUMMARY_REVISION_API_URL, '/api/voice/revise')
const textApiUrl = configuredUrl(undefined, '/api/voice/process-text')

export const voiceApiMode: 'server' | 'mock' = voiceApiUrl ? 'server' : 'mock'

function extensionFor(mimeType: string) {
  if (mimeType.includes('ogg')) return 'ogg'
  if (mimeType.includes('mp4')) return 'm4a'
  if (mimeType.includes('wav')) return 'wav'
  return 'webm'
}

function isVoiceProcessingResult(value: unknown): value is VoiceProcessingResult {
  if (!value || typeof value !== 'object') return false
  const result = value as Partial<VoiceProcessingResult>
  return typeof result.transcript === 'string'
    && Array.isArray(result.questions)
    && Boolean(result.summary)
    && typeof result.summary?.summary === 'string'
}

/**
 * Backend-ready boundary for Feature 383230.
 *
 * When VITE_VOICE_API_URL is configured, the captured recording is posted as
 * multipart/form-data under the `audio` field. With no URL, the UI stays fully
 * usable through the deterministic mock response.
 */
export async function submitVoiceNote(audio: Blob, sessionId?: string): Promise<VoiceProcessingResult> {
  if (!voiceApiUrl) return processVoiceNote(audio)

  const form = new FormData()
  form.append('audio', audio, `meeting-note.${extensionFor(audio.type)}`)
  form.append('mimeType', audio.type)
  form.append('size', String(audio.size))
  if (sessionId) form.append('sessionId', sessionId)

  const response = await fetch(voiceApiUrl, {
    method: 'POST',
    body: form,
    credentials: 'include',
  })

  if (!response.ok) {
    const details = await response.text().catch(() => '')
    throw new Error(details || `Voice processing failed (${response.status})`)
  }

  const result: unknown = await response.json()
  if (!isVoiceProcessingResult(result)) {
    throw new Error('Voice processing response does not match the expected schema')
  }
  return result
}

/** Text companion to the voice-processing boundary used by the live-chat UX. */
export async function processMeetingText(note: string): Promise<VoiceProcessingResult> {
  if (!textApiUrl) {
    const result = await processVoiceNote()
    return { ...result, transcript: note }
  }
  const response = await fetch(textApiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({ note }),
  })
  if (!response.ok) throw new Error(`Text note processing failed (${response.status})`)
  const result: unknown = await response.json()
  if (!isVoiceProcessingResult(result)) throw new Error('Text note response does not match the expected schema')
  return result
}

export async function reviseVoiceSummary(summary: MeetingSummary, instruction: string): Promise<MeetingSummary> {
  if (!revisionApiUrl) return reviseMeetingSummary(summary, instruction)
  const response = await fetch(revisionApiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({ summary, instruction }),
  })
  if (!response.ok) throw new Error(`Summary revision failed (${response.status})`)
  const result: unknown = await response.json()
  if (!result || typeof result !== 'object' || typeof (result as MeetingSummary).summary !== 'string') {
    throw new Error('Summary revision response does not match the expected schema')
  }
  return result as MeetingSummary
}
