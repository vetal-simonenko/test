import { resolveEntities } from '../mockApi';
import type { EntityResolutionItem, MeetingSummary } from '../types';
import { configuredUrl } from './runtimeConfig';

const entityApiUrl = configuredUrl(
	import.meta.env.VITE_ENTITY_RESOLUTION_API_URL,
	'/api/entities/resolve',
);

export const entityApiMode: 'server' | 'mock' = entityApiUrl
	? 'server'
	: 'mock';

export async function resolveMeetingEntities(
	summary: MeetingSummary,
): Promise<EntityResolutionItem[]> {
	if (!entityApiUrl) return resolveEntities(summary);
	const response = await fetch(entityApiUrl, {
		method: 'POST',
		headers: { 'Content-Type': 'application/json' },
		credentials: 'include',
		body: JSON.stringify({ summary }),
	});
	if (!response.ok)
		throw new Error(`Entity resolution failed (${response.status})`);
	const result: unknown = await response.json();
	if (!Array.isArray(result))
		throw new Error('Entity resolution response must be an array');
	return result as EntityResolutionItem[];
}
