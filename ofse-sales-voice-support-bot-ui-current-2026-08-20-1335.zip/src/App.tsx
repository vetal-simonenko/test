import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { getSessionUser, startEntraLogin, startLogout } from './services/authApi'
import { askCustomerBrief, createCustomerBrief, generateFollowUpEmail, reviseFollowUpEmail, saveSalesFeedback, sendFollowUpEmail } from './services/commercialApi'
import { createCvr } from './services/crmApi'
import { resolveMeetingEntities } from './services/entityApi'
import { startVoiceStream, type VoiceStreamController } from './services/streamingVoiceApi'
import { processMeetingText, reviseVoiceSummary, submitVoiceNote } from './services/voiceApi'
import type { AuthUser, CustomerBrief, EntityResolutionItem, FollowUpQuestion, MeetingSummary, StreamStatus, VoiceProcessingResult } from './types'

type Route = 'home' | 'alerts' | 'tasks' | 'cvrs' | 'chat' | 'brief' | 'settings' | 'language' | 'authentication'
type ChatIntent = 'meeting' | 'brief' | 'feedback' | null
type ChatStage = 'welcome' | 'capture' | 'clarifying' | 'review' | 'revision' | 'email-offer' | 'email-draft' | 'complete' | 'brief-context' | 'brief-ready' | 'feedback'
type VoiceModeState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'paused' | 'error'
type Message = { id: number; role: 'assistant' | 'user' | 'status'; text?: string; summary?: MeetingSummary; email?: string; brief?: CustomerBrief }
type ConversationSnapshot = { id: string; title: string; savedAt: string; messages: Message[] }
type TaskItem = { id: string; title: string; meta: string; done: boolean; priority: 'High' | 'Medium' | 'Low' }
type CvrItem = { id: string; customer: string; date: string; summary: string; status: 'Saved' | 'Draft' }

function Icon({ name, size = 24 }: { name: string; size?: number }) {
  const paths: Record<string, ReactNode> = {
    menu: <><path d="M4 7h16M4 12h16M4 17h11" /></>,
    close: <><path d="m5 5 14 14M19 5 5 19" /></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></>,
    home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v11h14V10M9 21v-7h6v7" /></>,
    tasks: <><path d="m4 6 2 2 4-4M4 13l2 2 4-4M4 20l2 2 4-4M13 6h7M13 13h7M13 20h7" /></>,
    cvr: <><path d="M6 3h9l4 4v14H6z" /><path d="M15 3v5h4M9 12h7M9 16h7" /></>,
    chat: <><circle cx="10" cy="8" r="4" /><path d="M3 21a7 7 0 0 1 14 0M19 5v6M22 7v2" /></>,
    settings: <><path d="M4 6h6M14 6h6M4 12h10M18 12h2M4 18h3M11 18h9" /><circle cx="12" cy="6" r="2" /><circle cx="16" cy="12" r="2" /><circle cx="9" cy="18" r="2" /></>,
    globe: <><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18" /></>,
    shield: <><path d="M12 3 5 6v5c0 5 3 8 7 10 4-2 7-5 7-10V6z" /><path d="M12 7v10" /></>,
    power: <><path d="M12 3v9M6.4 6.4a8 8 0 1 0 11.2 0" /></>,
    history: <><path d="M4 5v5h5" /><path d="M5.5 16.5A8 8 0 1 0 4 10M12 7v5l3 2" /></>,
    volume: <><path d="M11 5 6 9H3v6h3l5 4z" /><path d="M15 9a4 4 0 0 1 0 6M18 6a8 8 0 0 1 0 12" /></>,
    mic: <><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M6 11a6 6 0 0 0 12 0M12 17v4M9 21h6" /></>,
    pause: <><path d="M9 7v10M15 7v10" /></>,
    chevron: <path d="m9 18 6-6-6-6" />,
    check: <path d="m5 12 4 4L19 6" />,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m4 7 8 6 8-6" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v6M12 7h.01" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    arrow: <path d="m9 18 6-6-6-6" />,
  }
  return <svg className="icon" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.85" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>
}

function Brand({ light = false }: { light?: boolean }) {
  return <div className={`brand ${light ? 'light' : ''}`} aria-label="Baker Hughes"><strong>Baker Hughes</strong><span className="bh-mark"><i /><i /><i /></span></div>
}

function AssistantAvatar() { return <span className="assistant-avatar" aria-label="AI Sales Agent"><i /></span> }
function UserAvatar({ user, small = false }: { user: AuthUser; small?: boolean }) { return <span className={`person-avatar ${small ? 'small' : ''}`} aria-label={user.displayName}>{user.initials}</span> }

const initialTasks: TaskItem[] = [
  { id: 'task-1', title: 'Send Chevron pricing and references', meta: 'Today · Chevron', done: false, priority: 'High' },
  { id: 'task-2', title: 'Schedule the technical workshop', meta: 'Aug 24 · Chevron', done: false, priority: 'High' },
  { id: 'task-3', title: 'Validate ESP pricing position', meta: 'Aug 26 · ExxonMobil', done: false, priority: 'Medium' },
  { id: 'task-4', title: 'Share BP account brief with the team', meta: 'Aug 29 · bp', done: true, priority: 'Low' },
]
const initialCvrs: CvrItem[] = [
  { id: 'CVR-CHV-2048', customer: 'Chevron', date: 'Aug 10, 2026', summary: 'Asset performance management discussion and technical workshop follow-up.', status: 'Saved' },
  { id: 'CVR-BP-1982', customer: 'bp', date: 'Aug 7, 2026', summary: 'Production optimization priorities and next-step alignment.', status: 'Saved' },
  { id: 'CVR-XOM-1904', customer: 'ExxonMobil', date: 'Jul 29, 2026', summary: 'ESP performance evaluation for upcoming wells.', status: 'Saved' },
  { id: 'CVR-SHL-1881', customer: 'Shell', date: 'Jul 23, 2026', summary: 'Draft customer visit record awaiting final review.', status: 'Draft' },
]
const alerts = [
  { id: 'alert-1', title: 'Chevron call follow-up', detail: 'How did your call with Chevron go today?', time: '12:20 PM', unread: true },
  { id: 'alert-2', title: 'CVR saved', detail: 'Your Chevron CVR was synchronized with Deal Machine.', time: 'Yesterday', unread: false },
  { id: 'alert-3', title: 'Workshop reminder', detail: 'Technical workshop planning is due in two days.', time: 'Aug 18', unread: false },
]

function Header({ onMenu, onAlerts, alertCount }: { onMenu: () => void; onAlerts: () => void; alertCount: number }) {
  return <header className="top-bar"><button className="top-icon" onClick={onMenu} aria-label="Open menu"><Icon name="menu" size={27} /></button><Brand light /><button className="top-icon alert-button" onClick={onAlerts} aria-label={`${alertCount} unread alert`}><Icon name="bell" size={25} />{alertCount > 0 && <span>{alertCount}</span>}</button></header>
}

function BottomNav({ route, voiceState, onNavigate, onVoiceToggle }: { route: Route; voiceState: VoiceModeState; onNavigate: (route: Route) => void; onVoiceToggle: () => void }) {
  const items: { route: Route; icon: string; label: string }[] = [
    { route: 'home', icon: 'home', label: 'Home' },
    { route: 'tasks', icon: 'tasks', label: 'My tasks' },
    { route: 'cvrs', icon: 'cvr', label: 'My CVRs' },
  ]
  const onChat = route === 'chat'
  const voiceActive = onChat && !['idle', 'paused', 'error'].includes(voiceState)
  const voiceLabel = !onChat ? 'Live chat' : voiceState === 'paused' ? 'Resume voice' : voiceActive ? 'Pause voice' : voiceState === 'error' ? 'Retry voice' : 'Start voice'
  return <nav className="bottom-nav" aria-label="Primary navigation">
    {items.map((item) => <button key={item.route} className={route === item.route || (route === 'brief' && item.route === 'home') ? 'active' : ''} onClick={() => onNavigate(item.route)} aria-label={item.label}><span><Icon name={item.icon} size={26} /></span><small>{item.label}</small></button>)}
    <button className={`voice-nav ${voiceActive ? `active ${voiceState}` : ''}`} onClick={onVoiceToggle} aria-label={voiceLabel} aria-pressed={voiceActive}><span><Icon name={!onChat ? 'chat' : voiceActive ? 'pause' : 'mic'} size={25} /></span><small>{voiceLabel}</small></button>
  </nav>
}

function SideMenu({ user, onClose, onNavigate }: { user: AuthUser; onClose: () => void; onNavigate: (route: Route) => void }) {
  const mainItems = [
    { route: 'home' as Route, label: 'Home', icon: 'home' }, { route: 'alerts' as Route, label: 'My alerts', icon: 'bell' },
    { route: 'tasks' as Route, label: 'My tasks', icon: 'tasks' }, { route: 'cvrs' as Route, label: 'My CVRs', icon: 'cvr' },
    { route: 'chat' as Route, label: 'Live chat', icon: 'chat' },
  ]
  const settingsItems = [
    { route: 'settings' as Route, label: 'Settings', icon: 'settings' }, { route: 'language' as Route, label: 'Language', icon: 'globe', arrow: true },
    { route: 'authentication' as Route, label: 'Authentication', icon: 'shield' },
  ]
  const row = (item: { route: Route; label: string; icon: string; arrow?: boolean }) => <button className="menu-row" key={item.route} onClick={() => onNavigate(item.route)}><Icon name={item.icon} size={22} /><span>{item.label}</span>{item.arrow && <Icon name="arrow" size={18} />}</button>
  return <section className="side-menu page-enter"><div className="menu-top"><button className="top-icon" onClick={onClose} aria-label="Close menu"><Icon name="close" size={30} /></button><Brand light /><span /></div><div className="profile-block"><UserAvatar user={user} /><strong>{user.displayName}</strong><span>{user.email}</span></div><div className="menu-group">{mainItems.map(row)}</div><div className="menu-group">{settingsItems.map(row)}</div><div className="menu-group logout-group"><button className="menu-row" onClick={startLogout}><Icon name="power" size={22} /><span>Log out</span></button></div></section>
}

function HomePage({ user, onOpenChat, onOpenBrief }: { user: AuthUser; onOpenChat: (intent: ChatIntent) => void; onOpenBrief: (customer: string) => void }) {
  const [showUpdate, setShowUpdate] = useState(true)
  const now = new Date(); const firstName = user.displayName.split(' ')[0]
  const date = new Intl.DateTimeFormat('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' }).format(now)
  const time = new Intl.DateTimeFormat('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit' }).format(now)
  return <div className="home-page page-enter"><section className="home-intro"><h1>Good afternoon, {firstName}!</h1><p>{date} {time}</p></section><section className="home-section"><h2>Updates</h2>{showUpdate && <article className="update-card"><button className="dismiss" onClick={() => setShowUpdate(false)} aria-label="Dismiss update"><Icon name="close" size={18} /></button><AssistantAvatar /><div><p>How did your call with Chevron go today?</p><button className="live-chat-cta" onClick={() => onOpenChat('meeting')}><Icon name="chat" size={23} />Start live chat</button></div></article>}</section><section className="explore-section"><h2>Explore</h2><p>Swipe to see what teams are learning from customer engagements across Baker Hughes.</p><div className="customer-strip"><button className="customer-card chevron-logo" onClick={() => onOpenBrief('Chevron')}><strong>Chevron</strong><i><span /><span /></i></button><button className="customer-card bp-logo" onClick={() => onOpenBrief('bp')}><strong>bp</strong><i>✦</i></button><button className="customer-card exxon-logo" onClick={() => onOpenBrief('ExxonMobil')}><strong>ExxonMobil</strong><span>Energy · technology · progress</span></button></div></section></div>
}

function AlertsPage({ onStartChat }: { onStartChat: () => void }) {
  return <div className="collection-page page-enter"><div className="page-heading"><p>Inbox</p><h1>My alerts</h1></div><div className="collection-list">{alerts.map((item) => <article className={`collection-card ${item.unread ? 'unread' : ''}`} key={item.id}><span className="collection-icon"><Icon name="bell" size={21} /></span><div><strong>{item.title}</strong><p>{item.detail}</p><small>{item.time}</small>{item.id === 'alert-1' && <button className="inline-action" onClick={onStartChat}>Start live chat</button>}</div></article>)}</div></div>
}

function TasksPage({ tasks, onToggle }: { tasks: TaskItem[]; onToggle: (id: string) => void }) {
  return <div className="collection-page page-enter"><div className="page-heading"><p>Next steps</p><h1>My tasks</h1></div><div className="summary-pill">{tasks.filter((task) => !task.done).length} open · {tasks.filter((task) => task.done).length} completed</div><div className="collection-list">{tasks.map((task) => <article className={`task-card ${task.done ? 'done' : ''}`} key={task.id}><button className="task-check" onClick={() => onToggle(task.id)} aria-label={task.done ? 'Mark task open' : 'Complete task'}>{task.done && <Icon name="check" size={18} />}</button><div><span className={`priority ${task.priority.toLowerCase()}`}>{task.priority}</span><strong>{task.title}</strong><small>{task.meta}</small></div></article>)}</div></div>
}

function CvrsPage({ cvrs, onNew }: { cvrs: CvrItem[]; onNew: () => void }) {
  const [query, setQuery] = useState(''); const filtered = cvrs.filter((item) => `${item.customer} ${item.summary} ${item.id}`.toLowerCase().includes(query.toLowerCase()))
  return <div className="collection-page page-enter"><div className="page-heading row"><div><p>Customer visit records</p><h1>My CVRs</h1></div><button className="round-add" onClick={onNew} aria-label="Create CVR">+</button></div><label className="search-field"><Icon name="search" size={19} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search CVRs" /></label><div className="collection-list">{filtered.map((item) => <details className="cvr-card" key={item.id}><summary><span className="collection-icon"><Icon name="cvr" size={21} /></span><div><strong>{item.customer}</strong><small>{item.date} · {item.id}</small></div><span className={`record-status ${item.status.toLowerCase()}`}>{item.status}</span></summary><p>{item.summary}</p></details>)}</div></div>
}

function InfoPage({ route, user }: { route: Route; user: AuthUser }) {
  if (route === 'language') return <div className="info-page page-enter"><div className="page-heading"><p>Preferences</p><h1>Language</h1></div><label className="setting-card"><span><Icon name="globe" /><b>Assistant language</b></span><select defaultValue="English (US)"><option>English (US)</option><option>English (UK)</option><option>Ukrainian</option></select></label><p className="info-note">Voice transcription and generated content use the selected language when the backend supports it.</p></div>
  if (route === 'authentication') return <div className="info-page page-enter"><div className="page-heading"><p>Security</p><h1>Authentication</h1></div><article className="auth-status"><Icon name="shield" size={30} /><div><strong>Protected session</strong><p>{user.authProvider === 'mock' ? 'Mock Entra ID session for the frontend demo.' : `Signed in with Baker Hughes Entra ID as ${user.email}.`}</p></div></article><button className="settings-button" onClick={startLogout}><Icon name="power" />Log out</button></div>
  return <div className="info-page page-enter"><div className="page-heading"><p>Preferences</p><h1>Settings</h1></div><label className="toggle-row"><span><b>Read assistant replies aloud</b><small>Use browser text-to-speech for new replies.</small></span><input type="checkbox" /></label><label className="toggle-row"><span><b>Conversation receipts</b><small>Send confirmation receipts after shared emails.</small></span><input type="checkbox" defaultChecked /></label><label className="toggle-row"><span><b>Compact CVR preview</b><small>Hide empty fields in conversation cards.</small></span><input type="checkbox" defaultChecked /></label></div>
}

function BriefPage({ customer }: { customer: string }) {
  const [brief, setBrief] = useState<CustomerBrief | null>(null); const [question, setQuestion] = useState(''); const [answer, setAnswer] = useState(''); const [busy, setBusy] = useState(false)
  useEffect(() => { setBrief(null); setAnswer(''); setBusy(true); createCustomerBrief(`Prepare me for a meeting with ${customer}`).then(setBrief).finally(() => setBusy(false)) }, [customer])
  async function ask() { if (!question.trim() || !brief) return; setBusy(true); setAnswer(await askCustomerBrief(question, brief)); setQuestion(''); setBusy(false) }
  if (busy && !brief) return <div className="brief-page loading-page"><AssistantAvatar /><h1>Building the {customer} brief…</h1><div className="typing-dots"><i /><i /><i /></div></div>
  if (!brief) return null
  return <div className="brief-page page-enter">
    <div className="page-heading"><p>Customer intelligence</p><h1>{brief.title}</h1></div>
    <div className="account-pulse"><span className={`sentiment ${brief.sentiment.toLowerCase()}`}>{brief.sentiment}</span><p>Account pulse from CRM, engagement notes and commercial data.</p></div>
    <BriefBlock title="Context" items={brief.context} />
    <BriefBlock title="Stakeholders" items={brief.stakeholders} />
    <BriefBlock title="Open items" items={brief.openItems} />
    <section className="brief-block"><h2>Opportunities</h2>{brief.opportunities.map((opportunity) => <div className="opportunity-row" key={opportunity.id}><div><strong>{opportunity.name}</strong><small>{opportunity.stage}</small></div><b>{opportunity.value}</b></div>)}</section>
    <BriefBlock title="Pricing intelligence" items={brief.pricing} />
    {!!brief.pastEngagements?.length && <section className="brief-block"><h2>Past engagements</h2><div className="engagement-timeline">{brief.pastEngagements.map((engagement) => <article key={engagement.id}><i /><div><span>{engagement.date}</span><strong>{engagement.title}</strong><p>{engagement.outcome}</p><small>Owner: {engagement.owner}</small></div></article>)}</div></section>}
    {!!brief.sources?.length && <section className="brief-block"><div className="brief-block-heading"><h2>Reference sources</h2><span>{brief.sources.length} connected</span></div><div className="source-list">{brief.sources.map((source) => <article key={source.id}><span className={`source-system ${source.system.toLowerCase()}`}>{source.system}</span><div><strong>{source.title}</strong><small>Updated {source.updatedAt}</small></div>{source.url && <a href={source.url} target="_blank" rel="noreferrer" aria-label={`Open ${source.title}`}><Icon name="chevron" size={17} /></a>}</article>)}</div><p className="source-note"><Icon name="shield" size={15} />Access follows your permissions in each source system.</p></section>}
    <section className="brief-qa"><div><AssistantAvatar /><span><strong>Ask about this customer</strong><small>Answers use the connected agentic search and SQL retrieval boundaries.</small></span></div>{answer && <p>{answer}</p>}<label><input value={question} onChange={(event) => setQuestion(event.target.value)} onKeyDown={(event) => event.key === 'Enter' && void ask()} placeholder="Ask about risks, people or pricing" /><button onClick={() => void ask()} disabled={busy || !question.trim()}><Icon name="chevron" size={19} /></button></label></section>
  </div>
}
function BriefBlock({ title, items }: { title: string; items: string[] }) { return <section className="brief-block"><h2>{title}</h2><ul>{items.map((item) => <li key={item}>{item}</li>)}</ul></section> }

function SummaryCard({ summary, entities, onEntityChange }: { summary: MeetingSummary; entities: EntityResolutionItem[]; onEntityChange: (entityId: string, candidateId: string) => void }) {
  const details = [summary.summary, summary.statedNeeds, summary.objections, summary.actionItems].filter(Boolean); const linked = entities.filter((entity) => entity.selectedId).length
  return <div className="summary-card"><p>Great, thanks for sharing. Here is your CVR, let me know your thoughts.</p><div className="summary-meta"><em>Customer: {summary.customer}</em><em>Date: {new Intl.DateTimeFormat('en-US', { month: 'long', day: 'numeric', year: 'numeric' }).format(new Date())}</em></div>{details.slice(0, 3).map((detail) => <p className="summary-detail" key={detail}>{detail}</p>)}<span className="crm-link-status"><Icon name="check" size={15} />{linked || 1} CRM matches ready for review</span>{entities.length > 0 && <details className="entity-review"><summary>Review CRM matches</summary><div>{entities.map((entity) => { const selected = entity.candidates.find((candidate) => candidate.id === entity.selectedId); return <label key={entity.id}><span><b>{entity.label}{entity.required ? ' *' : ''}</b><small>{selected ? `${selected.matchMethod} · ${selected.confidence}%` : 'Original mention retained as context'}</small></span><select value={entity.selectedId} onChange={(event) => onEntityChange(entity.id, event.target.value)}>{!entity.required && <option value="">Don’t link</option>}{entity.candidates.map((candidate) => <option value={candidate.id} key={candidate.id}>{candidate.label}</option>)}</select></label> })}</div></details>}</div>
}
function EmailCard({ email }: { email: string }) { return <div className="email-draft-card"><span><Icon name="mail" size={18} />Draft email</span><pre>{email}</pre></div> }
function BriefMessageCard({ brief }: { brief: CustomerBrief }) { return <div className="brief-message-card"><span>Customer brief</span><strong>{brief.customer}</strong><ul>{brief.openItems.slice(0, 3).map((item) => <li key={item}>{item}</li>)}</ul><small>{brief.opportunities.length} active opportunities · {brief.sentiment} account pulse</small></div> }
function preferredRecordingType() { if (typeof MediaRecorder === 'undefined') return undefined; return ['audio/webm;codecs=opus', 'audio/mp4;codecs=mp4a.40.2', 'audio/webm', 'audio/ogg;codecs=opus'].find((type) => MediaRecorder.isTypeSupported(type)) }
const conversationHistoryKey = 'omnisource-conversation-history-v1'
const policyDismissedKey = 'omnisource-business-policy-dismissed'

function loadConversationHistory(): ConversationSnapshot[] {
  try {
    const stored = JSON.parse(window.localStorage.getItem(conversationHistoryKey) || '[]') as ConversationSnapshot[]
    return Array.isArray(stored) ? stored.filter((item) => item?.id && Array.isArray(item.messages)).slice(0, 12) : []
  } catch { return [] }
}

function ChatPage({ user, intent, sessionKey, voiceCommand, onVoiceStateChange, onCvrSaved }: { user: AuthUser; intent: ChatIntent; sessionKey: number; voiceCommand: number; onVoiceStateChange: (state: VoiceModeState) => void; onCvrSaved: (record: CvrItem) => void }) {
  const [stage, setStage] = useState<ChatStage>('welcome')
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [summary, setSummary] = useState<MeetingSummary | null>(null)
  const [entities, setEntities] = useState<EntityResolutionItem[]>([])
  const [questions, setQuestions] = useState<FollowUpQuestion[]>([])
  const [questionIndex, setQuestionIndex] = useState(0)
  const [email, setEmail] = useState('')
  const [brief, setBrief] = useState<CustomerBrief | null>(null)
  const [recording, setRecording] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const [liveTranscript, setLiveTranscript] = useState('')
  const [streamStatus, setStreamStatus] = useState<StreamStatus>('idle')
  const [voiceState, setVoiceState] = useState<VoiceModeState>('idle')
  const [history, setHistory] = useState<ConversationSnapshot[]>(loadConversationHistory)
  const [historyOpen, setHistoryOpen] = useState(false)
  const [showPolicy, setShowPolicy] = useState(() => { try { return window.localStorage.getItem(policyDismissedKey) !== 'true' } catch { return true } })

  const messageId = useRef(0)
  const messagesRef = useRef<Message[]>([])
  const mediaRef = useRef<MediaRecorder | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const voiceStreamRef = useRef<VoiceStreamController | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const chatScrollRef = useRef<HTMLDivElement | null>(null)
  const stageRef = useRef<ChatStage>('welcome')
  const busyRef = useRef(false)
  const recordingRef = useRef(false)
  const finishingRef = useRef(false)
  const captureTokenRef = useRef(0)
  const voiceSessionActiveRef = useRef(false)
  const liveTranscriptRef = useRef('')
  const elapsedRef = useRef(0)
  const finishRecordingRef = useRef<() => Promise<void>>(async () => undefined)
  const speechTokenRef = useRef(0)
  const lastSpokenMessageIdRef = useRef(0)
  const conversationIdRef = useRef<string | null>(null)
  const lastVoiceCommandRef = useRef(voiceCommand)

  const nextId = () => { messageId.current += 1; return messageId.current }
  const assistant = (text: string): Message => ({ id: nextId(), role: 'assistant', text })
  const userMessage = (text: string): Message => ({ id: nextId(), role: 'user', text })
  const setConversationStage = (next: ChatStage) => { stageRef.current = next; setStage(next) }
  const setConversationBusy = (next: boolean) => { busyRef.current = next; setBusy(next) }
  const setRecordingState = (next: boolean) => { recordingRef.current = next; setRecording(next) }
  const canListenAt = (current: ChatStage) => ['capture', 'clarifying', 'review', 'revision', 'email-offer', 'email-draft', 'brief-context', 'brief-ready', 'feedback'].includes(current)

  function updateStoredHistory(items: ConversationSnapshot[]) {
    setHistory(items)
    try { window.localStorage.setItem(conversationHistoryKey, JSON.stringify(items)) } catch { /* storage can be unavailable in embedded demos */ }
  }

  function saveCurrentConversation(sourceMessages = messages) {
    if (sourceMessages.filter((message) => message.role === 'user').length === 0) return
    const id = conversationIdRef.current || `chat-${Date.now()}`
    conversationIdRef.current = id
    const customer = [...sourceMessages].reverse().find((message) => message.summary)?.summary?.customer || [...sourceMessages].reverse().find((message) => message.brief)?.brief?.customer
    const latestUserText = [...sourceMessages].reverse().find((message) => message.role === 'user' && message.text)?.text
    const title = customer ? `${customer} conversation` : (latestUserText || 'Sales conversation').slice(0, 48)
    const snapshot: ConversationSnapshot = { id, title, savedAt: new Date().toISOString(), messages: sourceMessages }
    updateStoredHistory([snapshot, ...history.filter((item) => item.id !== id)].slice(0, 12))
  }

  async function stopCaptureResources() {
    captureTokenRef.current += 1
    const recorder = mediaRef.current
    if (recorder?.state === 'recording') {
      try { recorder.stop() } catch { /* recorder may already be stopping */ }
    }
    mediaRef.current = null
    try { await voiceStreamRef.current?.stop() } catch { /* transport is best effort during pause */ }
    voiceStreamRef.current = null
    streamRef.current?.getTracks().forEach((track) => track.stop())
    streamRef.current = null
    chunksRef.current = []
    setRecordingState(false)
    setStreamStatus('closed')
  }

  function resetConversation(nextIntent: ChatIntent = null, saveCurrent = true) {
    if (saveCurrent) saveCurrentConversation()
    voiceSessionActiveRef.current = false
    speechTokenRef.current += 1
    window.speechSynthesis?.cancel()
    void stopCaptureResources()
    conversationIdRef.current = null
    setInput('')
    setConversationBusy(false)
    setError('')
    setSummary(null)
    setEntities([])
    setQuestions([])
    setQuestionIndex(0)
    setEmail('')
    setBrief(null)
    setElapsed(0)
    elapsedRef.current = 0
    setLiveTranscript('')
    liveTranscriptRef.current = ''
    setStreamStatus('idle')
    setVoiceState('idle')
    lastSpokenMessageIdRef.current = 0
    if (nextIntent === 'meeting') { setConversationStage('capture'); setMessages([assistant('Tell me about the customer meeting, starting with Who, What, Why, and Where.')]) }
    else if (nextIntent === 'brief') { setConversationStage('brief-context'); setMessages([assistant('Which customer or opportunity should I prepare you for?')]) }
    else if (nextIntent === 'feedback') { setConversationStage('feedback'); setMessages([assistant('Tell me what worked, what was difficult, and what would help you in the next engagement.')]) }
    else { setConversationStage('welcome'); setMessages([]) }
  }

  function chooseIntent(nextIntent: Exclude<ChatIntent, null>) {
    if (nextIntent === 'meeting') { setMessages((items) => [...items, assistant('Tell me about the customer meeting, starting with Who, What, Why, and Where.')]); setConversationStage('capture') }
    if (nextIntent === 'brief') { setMessages((items) => [...items, assistant('Which customer or opportunity should I prepare you for?')]); setConversationStage('brief-context') }
    if (nextIntent === 'feedback') { setMessages((items) => [...items, assistant('Tell me what worked, what was difficult, and what would help you in the next engagement.')]); setConversationStage('feedback') }
  }

  async function acceptMeetingResult(result: VoiceProcessingResult) {
    const nextQuestions = result.questions.filter((item, index, all) => all.findIndex((candidate) => candidate.id === item.id || candidate.prompt === item.prompt) === index).slice(0, 5)
    setSummary(result.summary)
    setQuestions(nextQuestions)
    setQuestionIndex(0)
    try { setEntities(await resolveMeetingEntities(result.summary)) } catch { setEntities([]) }
    if (nextQuestions.length) { setMessages((items) => [...items, assistant(nextQuestions[0].prompt)]); setConversationStage('clarifying') }
    else { setMessages((items) => [...items, { id: nextId(), role: 'assistant', summary: result.summary }]); setConversationStage('review') }
  }

  function applyAnswerToSummary(current: MeetingSummary, question: FollowUpQuestion, answer: string) {
    if (!answer.trim() || /not sure/i.test(answer)) return current
    const topic = question.topic.toLowerCase()
    if (topic.includes('challenge') || topic.includes('goal') || topic.includes('need')) return { ...current, statedNeeds: answer.trim() }
    if (topic.includes('next')) return { ...current, nextCommitment: answer.trim(), actionItems: answer.trim() }
    if (topic.includes('compet')) return { ...current, competitors: answer.trim() }
    return { ...current, summary: `${current.summary} ${answer.trim()}` }
  }

  function changeEntity(entityId: string, candidateId: string) {
    setEntities((items) => items.map((item) => item.id === entityId ? { ...item, selectedId: candidateId, action: 'pending', resolvedAt: undefined } : item))
  }

  async function approveSummary(addUserMessage = true, allowWhileBusy = false) {
    if (!summary || (busyRef.current && !allowWhileBusy)) return
    if (entities.some((entity) => entity.required && !entity.selectedId)) { setError('Select one customer account before saving the CVR.'); return }
    if (addUserMessage) setMessages((items) => [...items, userMessage('Looks great!')])
    setConversationBusy(true)
    setError('')
    const resolvedEntities = entities.map((entity) => ({ ...entity, action: entity.selectedId ? 'confirmed' as const : 'removed' as const, resolvedAt: new Date().toISOString() }))
    try {
      const result = await createCvr(summary, resolvedEntities)
      setEntities(resolvedEntities)
      onCvrSaved({ id: result.id, customer: summary.customer, date: new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date()), summary: summary.summary, status: 'Saved' })
      setMessages((items) => [...items, assistant('Great, I’ve saved it to your CVR folder. Want me to draft an email and share it with a colleague of your choosing?')])
      setConversationStage('email-offer')
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'CVR creation failed. Your draft is still available.'); if (voiceSessionActiveRef.current) setVoiceState('error') }
    finally { setConversationBusy(false) }
  }

  async function createEmail(addUserMessage = true, allowWhileBusy = false) {
    if (!summary || (busyRef.current && !allowWhileBusy)) return
    if (addUserMessage) setMessages((items) => [...items, userMessage('Yes, please')])
    setConversationBusy(true)
    setError('')
    try {
      const draft = await generateFollowUpEmail(summary)
      setEmail(draft)
      setMessages((items) => [...items, { id: nextId(), role: 'assistant', email: draft }, assistant('What do you think of the email? Who would you like to send it to?')])
      setConversationStage('email-draft')
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'The email draft could not be generated.'); if (voiceSessionActiveRef.current) setVoiceState('error') }
    finally { setConversationBusy(false) }
  }

  async function handleUserInput(rawValue: string, audio?: { blob: Blob; sessionId?: string }) {
    let value = rawValue.trim()
    if (!value && !audio) return
    const currentStage = stageRef.current
    setInput('')
    setError('')
    setConversationBusy(true)
    try {
      let processedMeeting: VoiceProcessingResult | null = null
      if (currentStage === 'capture' && audio) {
        processedMeeting = await submitVoiceNote(audio.blob, audio.sessionId)
        value = processedMeeting.transcript || value
      }
      if (!value) value = `Voice note · ${Math.floor(elapsedRef.current / 60)}:${String(elapsedRef.current % 60).padStart(2, '0')}`
      setMessages((items) => [...items, userMessage(value)])
      setLiveTranscript('')
      liveTranscriptRef.current = ''

      if (currentStage === 'capture') await acceptMeetingResult(processedMeeting || await processMeetingText(value))
      else if (currentStage === 'clarifying' && summary) {
        const revised = applyAnswerToSummary(summary, questions[questionIndex], value)
        setSummary(revised)
        if (questionIndex + 1 < questions.length) { const nextIndex = questionIndex + 1; setQuestionIndex(nextIndex); setMessages((items) => [...items, assistant(questions[nextIndex].prompt)]) }
        else { setMessages((items) => [...items, { id: nextId(), role: 'assistant', summary: revised }]); setConversationStage('review') }
      }
      else if (currentStage === 'review' && summary) {
        if (/looks? (great|good)|approve|save|all good|yes/i.test(value)) await approveSummary(false, true)
        else { const revised = await reviseVoiceSummary(summary, value); setSummary(revised); setMessages((items) => [...items, assistant('I’ve updated the CVR. Please review the revised version.'), { id: nextId(), role: 'assistant', summary: revised }]); setConversationStage('review') }
      }
      else if (currentStage === 'revision' && summary) { const revised = await reviseVoiceSummary(summary, value); setSummary(revised); setMessages((items) => [...items, assistant('I’ve updated the CVR. Please review the revised version.'), { id: nextId(), role: 'assistant', summary: revised }]); setConversationStage('review') }
      else if (currentStage === 'email-offer') {
        if (/\b(no|not now|skip)\b/i.test(value)) { setMessages((items) => [...items, assistant('All set. Your CVR is saved and ready whenever you need it.')]); setConversationStage('complete') }
        else await createEmail(false, true)
      }
      else if (currentStage === 'email-draft' && email) { const receipt = await sendFollowUpEmail(email, [value]); setMessages((items) => [...items, assistant(`Sent! A receipt has been sent to your email. Message ${receipt.id} was shared with ${receipt.recipients.join(', ')}.`)]); setConversationStage('complete') }
      else if (currentStage === 'brief-context') { const nextBrief = await createCustomerBrief(`Prepare me for a meeting with ${value}`); setBrief(nextBrief); setMessages((items) => [...items, { id: nextId(), role: 'assistant', brief: nextBrief }, assistant('What else would you like to know about this customer?')]); setConversationStage('brief-ready') }
      else if (currentStage === 'brief-ready' && brief) { const answer = await askCustomerBrief(value, brief); setMessages((items) => [...items, assistant(answer)]) }
      else if (currentStage === 'feedback') { const receipt = await saveSalesFeedback(value, { source: 'live-chat', customer: summary?.customer }); setMessages((items) => [...items, assistant(`Thanks — I’ve saved that feedback for the engagement team. Reference ${receipt.id}.`)]); setConversationStage('complete') }
      else setMessages((items) => [...items, assistant('I can help document a customer meeting, prepare account context, or capture sales-engagement feedback.')])
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'The request could not be completed. Please try again.')
      if (voiceSessionActiveRef.current) { voiceSessionActiveRef.current = false; setVoiceState('error') }
    } finally { setConversationBusy(false) }
  }

  async function submitText(override?: string) {
    const value = (override ?? input).trim()
    if (!value || busyRef.current || recordingRef.current) return
    await handleUserInput(value)
  }

  async function startVoiceTurn(handsFree = false) {
    if (recordingRef.current || finishingRef.current || busyRef.current || !canListenAt(stageRef.current)) return
    const captureToken = captureTokenRef.current + 1
    captureTokenRef.current = captureToken
    setError('')
    setElapsed(0)
    elapsedRef.current = 0
    setLiveTranscript('')
    liveTranscriptRef.current = ''
    chunksRef.current = []
    if (handsFree) voiceSessionActiveRef.current = true
    setVoiceState('listening')
    try {
      if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') throw new Error('Voice recording is not supported in this browser.')
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      if (captureToken !== captureTokenRef.current) { stream.getTracks().forEach((track) => track.stop()); return }
      streamRef.current = stream
      const mimeType = preferredRecordingType()
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined)
      mediaRef.current = recorder
      recorder.ondataavailable = (event) => { if (event.data.size) chunksRef.current.push(event.data) }
      recorder.start(250)
      setRecordingState(true)
      setStreamStatus('connecting')
      const voiceController = await startVoiceStream(stream, {
        onStatus: setStreamStatus,
        onTranscript: (text, isFinal) => {
          liveTranscriptRef.current = text
          setLiveTranscript(text)
          if (isFinal && voiceSessionActiveRef.current && !finishingRef.current) window.setTimeout(() => void finishRecordingRef.current(), 320)
        },
        onError: (message) => { setError(message); voiceSessionActiveRef.current = false; setVoiceState('error'); void stopCaptureResources() },
      })
      if (captureToken !== captureTokenRef.current) { await voiceController.stop(); stream.getTracks().forEach((track) => track.stop()); return }
      voiceStreamRef.current = voiceController
    } catch (caught) {
      streamRef.current?.getTracks().forEach((track) => track.stop())
      setRecordingState(false)
      setStreamStatus('degraded')
      setError(caught instanceof Error ? caught.message : 'Microphone access could not be started.')
      voiceSessionActiveRef.current = false
      setVoiceState('error')
    }
  }

  async function finishRecording() {
    const recorder = mediaRef.current
    if (!recorder || recorder.state !== 'recording' || finishingRef.current) return
    finishingRef.current = true
    setRecordingState(false)
    if (voiceSessionActiveRef.current) setVoiceState('thinking')
    try {
      const sessionId = voiceStreamRef.current?.sessionId
      const blob = await new Promise<Blob>((resolve) => {
        recorder.addEventListener('stop', () => resolve(new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' })), { once: true })
        recorder.stop()
      })
      mediaRef.current = null
      await voiceStreamRef.current?.stop()
      voiceStreamRef.current = null
      streamRef.current?.getTracks().forEach((track) => track.stop())
      streamRef.current = null
      if (!blob.size) throw new Error('No audio was captured. Please try again.')
      const heard = liveTranscriptRef.current || `Voice note · ${Math.floor(elapsedRef.current / 60)}:${String(elapsedRef.current % 60).padStart(2, '0')}`
      await handleUserInput(heard, { blob, sessionId })
      if (!voiceSessionActiveRef.current) setVoiceState('idle')
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'The voice note could not be processed.')
      if (voiceSessionActiveRef.current) { voiceSessionActiveRef.current = false; setVoiceState('error') } else setVoiceState('idle')
    } finally { finishingRef.current = false; setConversationBusy(false) }
  }
  finishRecordingRef.current = finishRecording

  async function pauseVoiceMode() {
    voiceSessionActiveRef.current = false
    speechTokenRef.current += 1
    window.speechSynthesis?.cancel()
    if (liveTranscriptRef.current) setInput(liveTranscriptRef.current)
    await stopCaptureResources()
    setLiveTranscript('')
    liveTranscriptRef.current = ''
    setVoiceState('paused')
  }

  async function startVoiceMode() {
    if (busyRef.current) return
    const wasPaused = voiceState === 'paused'
    const wasWelcome = stageRef.current === 'welcome'
    const restarted = stageRef.current === 'complete'
    if (wasWelcome) chooseIntent('meeting')
    else if (restarted) resetConversation('meeting')
    voiceSessionActiveRef.current = true
    if (!wasPaused) {
      const latest = [...messagesRef.current].reverse().find((message) => message.role === 'assistant')
      const prompt = wasWelcome || restarted ? 'Tell me about the customer meeting, starting with Who, What, Why, and Where.' : speechText(latest)
      if (latest) lastSpokenMessageIdRef.current = latest.id
      speakText(prompt, true)
    } else await startVoiceTurn(true)
  }

  async function toggleVoiceMode() {
    if (voiceSessionActiveRef.current || ['listening', 'thinking', 'speaking'].includes(voiceState)) await pauseVoiceMode()
    else await startVoiceMode()
  }

  function speechText(message?: Message) {
    return message?.text || message?.summary?.summary || (message?.email ? 'I created the follow-up email draft. Please review it and tell me who should receive it.' : '') || (message?.brief ? `${message.brief.title}. ${message.brief.context.join('. ')}` : '')
  }

  function speakText(text: string, resumeHandsFree: boolean) {
    if (!text) return
    const token = speechTokenRef.current + 1
    speechTokenRef.current = token
    window.speechSynthesis?.cancel()
    setVoiceState('speaking')
    let finished = false
    let fallback = 0
    const complete = () => {
      if (finished || speechTokenRef.current !== token) return
      finished = true
      window.clearTimeout(fallback)
      if (resumeHandsFree && voiceSessionActiveRef.current && canListenAt(stageRef.current)) window.setTimeout(() => void startVoiceTurn(true), 260)
      else { if (resumeHandsFree) voiceSessionActiveRef.current = false; setVoiceState('idle') }
    }
    if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') { fallback = window.setTimeout(complete, 700); return }
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 0.98
    utterance.onend = complete
    utterance.onerror = complete
    fallback = window.setTimeout(complete, Math.max(1800, Math.min(9000, text.length * 48)))
    window.speechSynthesis.speak(utterance)
  }

  function speakLatest() {
    const latest = [...messages].reverse().find((message) => message.role === 'assistant')
    speakText(speechText(latest), false)
  }

  async function reviseEmail() {
    if (!email || busyRef.current) return
    setConversationBusy(true)
    setError('')
    try { const draft = await reviseFollowUpEmail(email, 'Make the message concise and ready for an internal sales team.'); setEmail(draft); setMessages((items) => [...items, { id: nextId(), role: 'assistant', email: draft }]) }
    catch (caught) { setError(caught instanceof Error ? caught.message : 'The draft could not be revised.') }
    finally { setConversationBusy(false) }
  }

  function restoreConversation(snapshot: ConversationSnapshot) {
    saveCurrentConversation()
    void pauseVoiceMode()
    conversationIdRef.current = snapshot.id
    messageId.current = snapshot.messages.reduce((maximum, message) => Math.max(maximum, message.id), messageId.current)
    setMessages(snapshot.messages)
    setSummary(null)
    setEntities([])
    setBrief(null)
    setEmail('')
    setConversationStage('complete')
    setHistoryOpen(false)
  }

  function dismissPolicy() {
    setShowPolicy(false)
    try { window.localStorage.setItem(policyDismissedKey, 'true') } catch { /* optional preference */ }
  }

  useEffect(() => {
    resetConversation(intent)
  }, [sessionKey])
  useEffect(() => { messagesRef.current = messages }, [messages])
  useEffect(() => { busyRef.current = busy }, [busy])
  useEffect(() => { onVoiceStateChange(voiceState) }, [voiceState, onVoiceStateChange])
  useEffect(() => { const scroll = chatScrollRef.current; if (scroll) scroll.scrollTo({ top: scroll.scrollHeight, behavior: 'smooth' }) }, [messages, busy, stage, liveTranscript])
  useEffect(() => { if (!recording) return; const timer = window.setInterval(() => setElapsed((value) => { elapsedRef.current = value + 1; return value + 1 }), 1000); return () => window.clearInterval(timer) }, [recording])
  useEffect(() => {
    if (!voiceSessionActiveRef.current || voiceState !== 'thinking' || busy) return
    const latest = [...messages].reverse().find((message) => message.role === 'assistant')
    if (!latest || latest.id === lastSpokenMessageIdRef.current) return
    lastSpokenMessageIdRef.current = latest.id
    speakText(speechText(latest), true)
  }, [messages, busy, voiceState])
  useEffect(() => { if (stage === 'complete') saveCurrentConversation(messages) }, [stage, messages])
  useEffect(() => {
    if (voiceCommand === lastVoiceCommandRef.current) return
    lastVoiceCommandRef.current = voiceCommand
    void toggleVoiceMode()
  }, [voiceCommand])
  useEffect(() => {
    const pauseWhenHidden = () => { if (document.hidden && voiceSessionActiveRef.current) void pauseVoiceMode() }
    document.addEventListener('visibilitychange', pauseWhenHidden)
    return () => document.removeEventListener('visibilitychange', pauseWhenHidden)
  }, [])
  useEffect(() => () => {
    onVoiceStateChange('idle')
    voiceSessionActiveRef.current = false
    speechTokenRef.current += 1
    window.speechSynthesis?.cancel()
    streamRef.current?.getTracks().forEach((track) => track.stop())
    void voiceStreamRef.current?.stop()
  }, [onVoiceStateChange])

  const quickActions = useMemo(() => {
    if (stage === 'welcome') return [{ label: 'Document a customer meeting', action: () => chooseIntent('meeting'), primary: true }, { label: 'Learn more about a customer', action: () => chooseIntent('brief') }, { label: 'Feedback on sales engagement', action: () => chooseIntent('feedback') }]
    if (stage === 'capture') return [{ label: 'Use sample meeting note', action: () => void submitText("Met with Brian from Chevron today. They are evaluating asset performance management, asked for pricing and references, and want a technical workshop next month."), primary: false }]
    if (stage === 'clarifying') return [{ label: 'I’m not sure', action: () => void submitText('I’m not sure') }, { label: 'Finalize CVR now', action: () => { if (!summary) return; setMessages((items) => [...items, { id: nextId(), role: 'assistant', summary }]); setConversationStage('review') } }]
    if (stage === 'review') return [{ label: 'Looks great!', action: () => void approveSummary(), primary: true }, { label: 'Need to revise', action: () => { setMessages((items) => [...items, userMessage('Need to revise'), assistant('Tell me what you’d like to change in the CVR.')]); setConversationStage('revision') } }]
    if (stage === 'email-offer') return [{ label: 'Yes, please', action: () => void createEmail(), primary: true }, { label: 'No, thank you', action: () => { setMessages((items) => [...items, userMessage('No, thank you'), assistant('All set. Your CVR is saved and ready whenever you need it.')]); setConversationStage('complete') } }]
    if (stage === 'email-draft') return [{ label: 'Send to the CWI Sales Team', action: () => void submitText('CWI Sales Team'), primary: true }, { label: 'Make the email shorter', action: () => void reviseEmail() }]
    if (stage === 'complete') return [{ label: 'Start a new conversation', action: () => resetConversation(null) }]
    return []
  }, [stage, summary, entities, email, busy, questions, questionIndex, input])

  const voiceStatusLabel = voiceState === 'listening' ? (streamStatus === 'connected' ? 'Listening' : 'Connecting') : voiceState === 'thinking' ? 'Thinking' : voiceState === 'speaking' ? 'Speaking' : voiceState === 'paused' ? 'Voice paused' : voiceState === 'error' ? 'Voice unavailable' : 'Text chat'
  const placeholder = recording ? `Listening… ${Math.floor(elapsed / 60)}:${String(elapsed % 60).padStart(2, '0')}` : stage === 'capture' ? 'Describe the meeting' : stage === 'email-draft' ? 'Recipient or email address' : 'Type here'
  const liveDraftVisible = recording || (voiceState === 'thinking' && Boolean(liveTranscript))

  return <div className="chat-page page-enter">
    <div className="chat-title"><div><h1>AI Sales Agent</h1><p>Live chat <span className={`voice-status ${voiceState}`}>{voiceStatusLabel}</span></p></div><div><button onClick={() => setHistoryOpen(true)} aria-label="Open conversation history"><Icon name="history" size={27} /></button><button className="outlined" onClick={speakLatest} aria-label="Read latest reply"><Icon name="volume" size={28} /></button></div></div>
    {showPolicy && <div className="policy-notice"><Icon name="shield" size={17} /><p><strong>Business use only.</strong> Capture customer information in line with Baker Hughes communication policies.</p><button onClick={dismissPolicy} aria-label="Dismiss policy reminder"><Icon name="close" size={16} /></button></div>}
    <div className="chat-scroll" ref={chatScrollRef}><div className="message-stack">
      {messages.map((message) => <div className={`message-row ${message.role}`} key={message.id}>{message.role === 'assistant' && <AssistantAvatar />}<div className="message-content">{message.text && <div className="message-bubble">{message.text}</div>}{message.summary && <SummaryCard summary={message.summary} entities={entities} onEntityChange={changeEntity} />}{message.email && <EmailCard email={message.email} />}{message.brief && <BriefMessageCard brief={message.brief} />}</div>{message.role === 'user' && <UserAvatar user={user} small />}</div>)}
      {liveDraftVisible && <div className="message-row user live-message" aria-live="polite"><div className="message-content"><div className="message-bubble"><span className="live-label"><i />{voiceState === 'thinking' ? 'Processing your message' : 'Listening live'}</span><p>{liveTranscript || 'Speak naturally — your words will appear here.'}</p><span className="live-wave" aria-hidden="true">{Array.from({ length: 12 }, (_, index) => <i key={index} />)}</span></div></div><UserAvatar user={user} small /></div>}
      {busy && !liveDraftVisible && <div className="message-row assistant"><AssistantAvatar /><div className="typing-dots"><i /><i /><i /></div></div>}
      {error && <div className="chat-error" role="alert"><Icon name="info" size={17} /><span>{error}</span></div>}
      <div />
    </div></div>
    {quickActions.length > 0 && <div className="quick-actions">{quickActions.map((action) => <button className={action.primary ? 'primary' : ''} onClick={action.action} key={action.label} disabled={busy || recording}>{action.label}</button>)}</div>}
    <div className="chat-composer"><input value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => event.key === 'Enter' && void submitText()} placeholder={placeholder} disabled={busy || recording} /><button className={`composer-mic ${recording ? 'recording' : ''}`} onClick={() => recording ? (voiceSessionActiveRef.current ? void pauseVoiceMode() : void finishRecording()) : void startVoiceTurn(false)} disabled={busy || (!canListenAt(stage) && !recording)} aria-label={recording ? 'Stop recording' : 'Record voice message'}><Icon name={recording ? 'pause' : 'mic'} size={21} /></button><button className="composer-send" onClick={() => void submitText()} disabled={busy || recording || !input.trim()} aria-label="Send"><Icon name="chevron" size={20} /></button></div>
    {historyOpen && <div className="history-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setHistoryOpen(false) }}><section className="history-sheet" role="dialog" aria-modal="true" aria-labelledby="history-title"><div className="history-heading"><div><p>Saved locally on this device</p><h2 id="history-title">Conversation history</h2></div><button onClick={() => setHistoryOpen(false)} aria-label="Close history"><Icon name="close" size={22} /></button></div><button className="new-conversation" onClick={() => { setHistoryOpen(false); resetConversation(null) }}>+ Start a new conversation</button><div className="history-list">{history.length === 0 && <p className="empty-history">Completed and replaced conversations will appear here.</p>}{history.map((item) => <button key={item.id} onClick={() => restoreConversation(item)}><span><strong>{item.title}</strong><small>{new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date(item.savedAt))}</small></span><Icon name="chevron" size={18} /></button>)}</div></section></div>}
  </div>
}

function AuthScreen({ loading, error }: { loading: boolean; error: string }) { return <div className="auth-shell"><div className="auth-brand"><Brand light /></div><div className="auth-card"><AssistantAvatar /><p className="eyebrow">OmniSource Commercial Assistant</p><h1>{loading ? 'Checking secure session…' : 'Sign in to continue'}</h1><p>{loading ? 'Connecting to the AWS-hosted application.' : 'Use your Baker Hughes Entra ID account to start a protected voice or text session.'}</p>{error && <div className="chat-error">{error}</div>}{!loading && <button onClick={startEntraLogin}><Icon name="user" />Sign in with Entra ID</button>}</div></div> }

export default function App() {
  const [user, setUser] = useState<AuthUser | null | undefined>(undefined); const [sessionError, setSessionError] = useState(''); const [route, setRoute] = useState<Route>('home'); const [menuOpen, setMenuOpen] = useState(false); const [tasks, setTasks] = useState(initialTasks); const [cvrs, setCvrs] = useState(initialCvrs); const [chatIntent, setChatIntent] = useState<ChatIntent>(null); const [chatSessionKey, setChatSessionKey] = useState(0); const [voiceCommand, setVoiceCommand] = useState(0); const [voiceState, setVoiceState] = useState<VoiceModeState>('idle'); const [briefCustomer, setBriefCustomer] = useState('Chevron')
  useEffect(() => { getSessionUser().then(setUser).catch((caught) => { setSessionError(caught instanceof Error ? caught.message : 'Unable to verify the user session.'); setUser(null) }) }, [])
  function navigate(nextRoute: Route) { setRoute(nextRoute); setMenuOpen(false); document.querySelector('.app-body')?.scrollTo({ top: 0 }) }
  function openChat(intent: ChatIntent = null) { setChatIntent(intent); setChatSessionKey((key) => key + 1); navigate('chat') }
  function toggleVoiceFromNav() { if (route !== 'chat') openChat(null); else setVoiceCommand((command) => command + 1) }
  function openBrief(customer: string) { setBriefCustomer(customer); navigate('brief') }
  function addCvr(record: CvrItem) { setCvrs((items) => [record, ...items.filter((item) => item.id !== record.id)]) }
  if (user === undefined) return <AuthScreen loading error={sessionError} />
  if (!user) return <AuthScreen loading={false} error={sessionError} />
  if (menuOpen) return <div className="app-shell"><div className="mobile-frame"><SideMenu user={user} onClose={() => setMenuOpen(false)} onNavigate={(nextRoute) => nextRoute === 'chat' ? openChat(null) : navigate(nextRoute)} /></div></div>
  return <div className="app-shell"><div className="mobile-frame"><Header onMenu={() => setMenuOpen(true)} onAlerts={() => navigate('alerts')} alertCount={1} /><main className={`app-body ${route === 'chat' ? 'chat-body' : ''}`}>{route === 'home' && <HomePage user={user} onOpenChat={openChat} onOpenBrief={openBrief} />}{route === 'alerts' && <AlertsPage onStartChat={() => openChat('meeting')} />}{route === 'tasks' && <TasksPage tasks={tasks} onToggle={(id) => setTasks((items) => items.map((item) => item.id === id ? { ...item, done: !item.done } : item))} />}{route === 'cvrs' && <CvrsPage cvrs={cvrs} onNew={() => openChat('meeting')} />}{route === 'chat' && <ChatPage user={user} intent={chatIntent} sessionKey={chatSessionKey} voiceCommand={voiceCommand} onVoiceStateChange={setVoiceState} onCvrSaved={addCvr} />}{route === 'brief' && <BriefPage customer={briefCustomer} />}{(route === 'settings' || route === 'language' || route === 'authentication') && <InfoPage route={route} user={user} />}</main><BottomNav route={route} voiceState={voiceState} onNavigate={navigate} onVoiceToggle={toggleVoiceFromNav} /></div></div>
}
