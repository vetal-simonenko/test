import { mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const projectRoot = join(dirname(fileURLToPath(import.meta.url)), '..')
const distDirectory = join(projectRoot, 'dist')
const demoDirectory = join(projectRoot, 'manager-demo')
const sourceHtml = await readFile(join(distDirectory, 'index.html'), 'utf8')

const scriptMatch = sourceHtml.match(/<script[^>]+src="([^"]+)"[^>]*><\/script>/)
const styleMatch = sourceHtml.match(/<link[^>]+href="([^"]+\.css)"[^>]*>/)

if (!scriptMatch || !styleMatch) {
  throw new Error('Could not locate the Vite JavaScript and CSS assets.')
}

const resolveAsset = (assetPath) => join(distDirectory, assetPath.replace(/^\//, ''))
const javascript = (await readFile(resolveAsset(scriptMatch[1]), 'utf8')).replace(/<\/script/gi, '<\\/script')
const stylesheet = (await readFile(resolveAsset(styleMatch[1]), 'utf8'))
  .replace(/@import\s+(?:url\([^)]*\)|"[^"]*"|'[^']*'|[^;]*);?/gi, '')
  .replace(/<\/style/gi, '<\\/style')

const standaloneHtml = sourceHtml
  .replace(styleMatch[0], () => `<style>${stylesheet}</style>`)
  .replace(scriptMatch[0], () => `<script type="module">${javascript}</script>`)
  .replace('</head>', '    <!-- Self-contained manager demo: no server or installation required. -->\n  </head>')

const instructions = `SALES VOICE AGENT — MANAGER DEMO

1. Double-click Sales-Voice-Agent-Demo.html.
2. Use the "Use sample note" option for the most reliable demonstration.
3. Follow the questions, accept or change the suggested CRM links, and save the mock CVR.
4. Open the Brief tab to view the pre-meeting workflow.

This is a frontend prototype running with deterministic mock data.
No recording or customer information is transmitted when it displays Mock mode.
Real AWS, Salesforce, Databricks, Outlook, and Entra ID services are not connected.
Microphone access may be restricted when the file is opened directly from disk.
`

const demoGuide = `SALES VOICE AGENT — QUICK DEMO GUIDE

GETTING STARTED
1. Open Sales-Voice-Agent-Demo.html in Microsoft Edge or Google Chrome.
2. The prototype starts in Mock mode. No customer information or recording is transmitted.
3. Use Use sample note for the most reliable demonstration.

POST-MEETING NOTES
1. On the Notes tab, click Use sample note.
2. Review the raw transcript and the latest structured summary.
3. For the first follow-up question, enter: The customer needs a solution before September
4. Click Continue.
5. On the next question, click Skip to see how optional questions are handled.
6. Click Finalize now to complete the questioning stage early.

CRM MATCHES
1. Review the automatically selected Account, Opportunity, and Participant matches.
2. Click Change matches only if a suggestion needs adjustment.
3. Click Continue. One confirmation accepts the selected matches.

CVR REVIEW AND SAVE
1. Review the expandable meeting summary. The duplicate editable form has been removed for a simpler mobile flow.
2. To request a correction, type it into Tell the agent what to change, or use the microphone button in Edge/Chrome.
3. Click Save CVR.
4. Review the generated internal follow-up email draft.
5. To revise it, type or speak a request in Change the email. Try: Make it shorter
6. The displayed CVR ID is prototype data and is not sent to Deal Machine.

PRE-MEETING BRIEF
1. Click the Brief tab at the top of the application.
2. Keep the sample meeting context or replace it with another customer request.
3. Click Generate briefing.
4. Review the customer context, stakeholders, open items, opportunities, and pricing intelligence.
5. In Ask about this brief, enter: What are the main customer risks?
6. Submit the question to view a sample assistant response.

START AGAIN
Use the circular arrow button in the top-right corner to clear the current flow and return to the initial screen.

PROTOTYPE LIMITATIONS
- The demo uses deterministic mock data.
- AWS Transcribe, Salesforce, Databricks, Outlook, Microsoft Graph, and Entra ID are not connected.
- Direct-file microphone access may be restricted by browser or corporate security policy.
- Voice correction uses browser speech recognition and requires microphone permission in Edge/Chrome.
`

await rm(demoDirectory, { recursive: true, force: true })
await mkdir(demoDirectory, { recursive: true })
await writeFile(join(demoDirectory, 'Sales-Voice-Agent-Demo.html'), standaloneHtml)
await writeFile(join(demoDirectory, 'README.txt'), instructions)
await writeFile(join(demoDirectory, 'DEMO_GUIDE.txt'), demoGuide)

console.log(`Manager demo created in ${demoDirectory}`)
