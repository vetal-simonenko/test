# OmniSource Commercial Assistant — mobile frontend prototype

Mobile-first React 19 prototype aligned with the final IT-delivery UX mockups, the Sales Voice Agent POC, epic 383203, its child features, and the OmniSource Enterprise Architecture Design v1.4.

## Run locally

```bash
npm install
npm run dev
```

Microphone capture requires browser permission and a secure context (`localhost` during development or HTTPS when deployed).

## Build a standalone manager demo

```bash
npm run build:manager-demo
```

This creates `manager-demo/Sales-Voice-Agent-Demo.html`, a self-contained mock-mode demonstration that can be opened directly without Node.js or a web server. Use **Use sample note** for the most reliable flow; direct-file microphone access depends on browser policy.

## Implemented flows

- Final UX shell: Baker Hughes header, notifications, bottom navigation, user menu, the manager-approved simplified Home (call prompt plus customer exploration), alerts, tasks, CVR library, settings, language and authentication views.
- Conversational Live Chat: quick intents for meeting documentation, customer intelligence and sales-engagement feedback; text and voice capture; persistent on-device conversation history; browser read-aloud; loading, error and receipt states.
- Feature 383230: real browser audio capture with timer, a live transcript that grows inside the user message, processing and permission/error states, structured summary, dynamic follow-up questions, skip, and early finalize.
- Hands-free voice mode: the persistent bottom-right control opens Live Chat silently from other screens, then starts, pauses and resumes voice only after an explicit press inside Chat. The assistant speaks its prompt, listens for a final utterance, processes it, replies aloud and automatically resumes listening while the conversation expects an answer. Hiding the browser tab pauses an active voice session instead of resuming queued speech when the tab becomes visible again.
- Architecture v1.4: Entra-aware application session, AWS gateway boundary, PCM signed-16-bit/16 kHz mono streaming over a short-lived WebSocket, live transcript events, connection/reconnection/degraded states, retry, and local recording fallback.
- Extended voice-capture stories: latest-summary panel, browser text-to-speech, natural-language correction boundary, hidden missing fields, maximum-five/duplicate-topic question guardrails, and the expanded CRM-critical field set.
- Feature 383232: in-conversation Account/Opportunity/Participant entity review with best matches preselected, optional match changes, a required Account gate, decision metadata, a compact CVR summary, and mocked Deal Machine save.
- Feature 383235/383595: internal follow-up email preview, natural-language revision, recipient selection, send/receipt UI, and a Microsoft Graph-ready backend gateway boundary.
- Feature 383234: pre-meeting context input, customer briefing, opportunities, pricing context, past engagements, permission-aware reference-source cards, and follow-up Q&A.
- Sales-engagement feedback: policy reminder, persisted feedback receipt and a dedicated backend gateway boundary.

## Voice processing API

Without configuration, the browser records a real audio blob but processing returns deterministic mock data so the complete UI can be demonstrated.

Copy `.env.example` to `.env.local`. The preferred production configuration is a single AWS backend gateway:

```env
VITE_BACKEND_BASE_URL=https://commercial-assistant.example.bakerhughes.com
```

This enables the following same-gateway contracts:

- `GET /api/session` — current user established by the AWS/Entra ID authentication layer;
- `POST /api/voice/sessions` — accepts `{ encoding: "pcm_s16le", sampleRate: 16000, channels: 1 }` and returns a short-lived `websocketUrl` and `sessionId`;
- WebSocket binary frames — mono PCM16 audio; server events use `{ type: "transcript", text, isFinal }`, `{ type: "reconnecting" }`, or `{ type: "error", message }`;
- `POST /api/voice/process` — multipart recording plus the `sessionId` returned by the streaming session, allowing the backend to correlate the final request with AWS Transcribe output;
- `POST /api/voice/process-text` — accepts `{ note }` and returns the same structured response as voice processing;
- `/api/voice/revise`, `/api/entities/resolve`, `/api/cvrs`, `/api/follow-up/draft`, `/api/follow-up/revise`, `/api/briefs`, and `/api/briefs/questions` complete the browser-facing gateway surface;
- `POST /api/follow-up/send` — accepts `{ email, recipients }` and returns `{ id, recipients }` after the backend performs the approved Microsoft Graph/Outlook action.
- `POST /api/feedback` — accepts `{ feedback, context: { source: "live-chat", customer? } }` and returns `{ id, savedAt }` for the UI receipt.

The `POST /api/briefs` response may include `pastEngagements[]` and `sources[]`. Source items identify Salesforce, SharePoint, Databricks or Outlook and may include a permission-gated `url`; the browser never receives source-system credentials.

Individual endpoint overrides remain available only for transition/testing:

```env
VITE_VOICE_API_URL=https://api.example.com/voice-notes/process
VITE_SUMMARY_REVISION_API_URL=https://api.example.com/voice-notes/revise
VITE_ENTITY_RESOLUTION_API_URL=https://api.example.com/entities/resolve
VITE_CVR_API_URL=https://api.example.com/cvrs
```

The client then sends `multipart/form-data` with:

- `audio`: captured file (`webm`, `m4a`, or another browser-supported format)
- `mimeType`: browser-reported MIME type
- `size`: blob size in bytes

Expected JSON response:

```json
{
  "transcript": "...",
  "questions": [{ "id": "q1", "topic": "Next steps", "prompt": "..." }],
  "summary": {
    "customer": "...",
    "opportunityId": "...",
    "opportunity": "...",
    "sentiment": "Positive",
    "participants": "...",
    "products": "...",
    "dealSignals": "...",
    "decisionMakers": "...",
    "statedNeeds": "...",
    "timeline": "...",
    "objections": "...",
    "actionItems": "...",
    "blockers": "...",
    "competitors": "...",
    "summary": "..."
  }
}
```

The API boundary lives in `src/services/voiceApi.ts`; remaining simulated operations live in `src/mockApi.ts`.

The revision endpoint accepts `{ "summary": {...}, "instruction": "Timeline is Q4" }` and returns the revised `MeetingSummary`.

Entity resolution receives `{ "summary": {...} }` and returns `EntityResolutionItem[]`. CVR creation receives the finalized summary plus `entityResolution` decisions, so the backend can persist match method, confidence, user action, and resolution timestamps.

## Integration ownership

- The browser first requests a voice session from the authenticated AWS gateway, then sends PCM audio to the returned short-lived WebSocket URL. Long-lived AWS credentials never enter the browser.
- AWS Transcribe, Kafka publication, Bedrock/LangGraph orchestration, Salesforce, MS Graph, SharePoint, Databricks, S3, and Neptune remain behind the backend gateway; the browser does not connect to them directly.
- With no `VITE_BACKEND_BASE_URL`, the app explicitly identifies itself as Mock mode. It records real local audio and emits a deterministic prototype transcript without transmitting audio.
- Entity candidates, confidence, match method, resolution metadata, Bronze chunks, Silver counts, retry state, and audit links require CRM/Databricks APIs. The current UI uses explicitly labelled prototype data for these states.

## Deliberately unavailable until contracts exist

- Voice transcription/AI extraction from the actual recording when no API URL is configured.
- Production live transcript and progressive server-generated summary updates until the AWS endpoint/event contract is deployed (the client contract and UI are implemented).
- Production Outlook delivery remains dependent on the `/api/follow-up/send` Microsoft Graph backend implementation; mock mode exercises the complete approval and receipt UX without transmitting a message.
- Feature 383236: reading meeting and participant data from Outlook (`TBC`).
- Feature 383596: automated reminders (`TBC`, no description or acceptance criteria yet).
- Real AWS Transcribe, Bedrock/LangGraph, CRM entity matching, Deal Machine, Kafka, Databricks Bronze/Silver, Outlook/MS Graph, SharePoint, Neptune, audit, and Entra-backed session integrations.
