import { useEffect, useRef, useState } from 'react'
import { processVoiceNote } from './mockApi'
import { createCvr, cvrApiMode } from './services/crmApi'
import { entityApiMode, resolveMeetingEntities } from './services/entityApi'
import { reviseVoiceSummary, submitVoiceNote, voiceApiMode } from './services/voiceApi'
import { backendMode } from './services/runtimeConfig'
import { getSessionUser, startEntraLogin, startLogout } from './services/authApi'
import { startVoiceStream, type VoiceStreamController } from './services/streamingVoiceApi'
import { askCustomerBrief, createCustomerBrief, generateFollowUpEmail } from './services/commercialApi'
import type { AppMode, AuthUser, CustomerBrief, EntityResolutionItem, FollowUpQuestion, MeetingSummary, NotesStep, PipelineStatus, StreamStatus } from './types'

function Icon({ name, size = 20 }: { name: string; size?: number }) {
  const paths: Record<string, React.ReactNode> = {
    mic: <><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M6 11a6 6 0 0 0 12 0M12 17v4M9 21h6"/></>,
    note: <><path d="M6 3h9l3 3v15H6z"/><path d="M14 3v4h4M9 11h6M9 15h6"/></>,
    brief: <><rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V2h6v2M8 9h8M8 13h8M8 17h5"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    skip: <><path d="m6 5 9 7-9 7z"/><path d="M18 5v14"/></>,
    edit: <><path d="m4 20 4-1 11-11-3-3L5 16z"/><path d="m14 7 3 3"/></>,
    send: <><path d="m3 3 18 9-18 9 4-9z"/><path d="M7 12h14"/></>,
    spark: <><path d="m12 3 1.2 4.2L17 9l-3.8 1.8L12 15l-1.2-4.2L7 9l3.8-1.8z"/><path d="m5 15 .7 2.3L8 18l-2.3.7L5 21l-.7-2.3L2 18l2.3-.7z"/></>,
    chevron: <path d="m9 18 6-6-6-6"/>,
    reset: <><path d="M4 12a8 8 0 1 0 2.3-5.7L4 8"/><path d="M4 3v5h5"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
    volume: <><path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15 9a4 4 0 0 1 0 6M18 6a8 8 0 0 1 0 12"/></>,
    alert: <><path d="M12 3 2 21h20z"/><path d="M12 9v5M12 18h.01"/></>,
    cloud: <><path d="M7 18h10a4 4 0 0 0 .5-8A6 6 0 0 0 6 9a4.5 4.5 0 0 0 1 9z"/></>,
  }
  return <svg className="icon" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>
}

function Waveform({ active = false }: { active?: boolean }) {
  return <div className={`waveform ${active ? 'active' : ''}`} aria-hidden="true">
    {[12, 22, 34, 18, 44, 28, 16, 38, 24, 12, 30, 18, 40, 22, 14, 28].map((height, i) => <span key={i} style={{ height }} />)}
  </div>
}

function formatTime(seconds: number) {
  return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`
}

const streamLabels: Record<StreamStatus, string> = {
  idle: 'Not connected', connecting: 'Connecting to AWS', connected: 'Live transcription connected',
  reconnecting: 'Reconnecting', degraded: 'Streaming unavailable', closed: 'Stream completed',
}

function preferredRecordingType() {
  if (typeof MediaRecorder === 'undefined') return undefined
  return [
    'audio/webm;codecs=opus',
    'audio/mp4;codecs=mp4a.40.2',
    'audio/webm',
    'audio/ogg;codecs=opus',
  ].find((type) => MediaRecorder.isTypeSupported(type))
}

function recordingErrorMessage(error: unknown) {
  if (error instanceof DOMException && error.name === 'NotAllowedError') return 'Microphone access was denied. Allow it in the browser site settings and try again.'
  if (error instanceof DOMException && error.name === 'NotFoundError') return 'No microphone was found on this device.'
  if (error instanceof DOMException && error.name === 'NotReadableError') return 'The microphone is busy in another application.'
  return 'The microphone could not be started. Check browser permissions and try again.'
}

function normalizeQuestions(items: FollowUpQuestion[]) {
  return items.filter((item, index, all) => all.findIndex((candidate) => candidate.id === item.id || candidate.prompt === item.prompt || candidate.topic === item.topic) === index).slice(0, 5)
}

const emptySummary: MeetingSummary = {
  customer: '', opportunityId: 'account', opportunity: 'Account-level CVR', sentiment: 'Mixed', participants: '',
  products: '', dealSignals: '', decisionMakers: '', statedNeeds: '', timeline: '', objections: '', actionItems: '',
  blockers: '', competitors: '', competitorStrengths: '', competitorWeaknesses: '', decisionProcess: '',
  procurementConstraints: '', incumbentFootprint: '', nextCommitment: '', summary: '',
}

function normalizeSummary(summary: Partial<MeetingSummary>): MeetingSummary {
  return { ...emptySummary, ...summary }
}

type SummaryTextKey = Exclude<keyof MeetingSummary, 'opportunityId' | 'sentiment'>
const summaryFields: { key: SummaryTextKey; label: string; multiline?: boolean }[] = [
  { key: 'summary', label: 'Summary', multiline: true },
  { key: 'participants', label: 'Participants', multiline: true },
  { key: 'products', label: 'Products' },
  { key: 'dealSignals', label: 'Deal signals', multiline: true },
  { key: 'decisionMakers', label: 'Decision makers', multiline: true },
  { key: 'decisionProcess', label: 'Decision process / approval path', multiline: true },
  { key: 'procurementConstraints', label: 'Procurement / commercial constraints', multiline: true },
  { key: 'statedNeeds', label: 'Customer needs', multiline: true },
  { key: 'objections', label: 'Questions / objections', multiline: true },
  { key: 'actionItems', label: 'Actions / next steps', multiline: true },
  { key: 'nextCommitment', label: 'Next meeting / milestone commitment', multiline: true },
  { key: 'blockers', label: 'Blockers', multiline: true },
  { key: 'competitors', label: 'Competitors' },
  { key: 'competitorStrengths', label: 'Competitor strengths', multiline: true },
  { key: 'competitorWeaknesses', label: 'Competitor weaknesses', multiline: true },
  { key: 'incumbentFootprint', label: 'Incumbent footprint', multiline: true },
  { key: 'timeline', label: 'Timeline' },
]

function SummarySnapshot({ summary, speaking, onSpeak }: { summary: MeetingSummary; speaking: boolean; onSpeak: () => void }) {
  const populated = summaryFields.filter(({ key }) => summary[key]?.trim())
  return <details className="summary-snapshot">
    <summary>Latest structured summary <span>{populated.length} captured fields</span></summary>
    <div className="snapshot-content">
      <div className="snapshot-toolbar"><span className={`sentiment ${summary.sentiment.toLowerCase()}`}>{summary.sentiment}</span><button className="secondary compact" onClick={onSpeak}><Icon name="volume" size={16}/>{speaking ? 'Stop reading' : 'Read aloud'}</button></div>
      {populated.map(({ key, label }) => <div className="snapshot-row" key={key}><small>{label}</small><p>{summary[key]}</p></div>)}
    </div>
  </details>
}

function Header({ onReset, user }: { onReset: () => void; user: AuthUser }) {
  return <header className="app-header">
    <div className="brand-mark"><span /><span /></div>
    <div>
      <strong>Sales Agent</strong>
      <small>AI-powered commercial assistant</small>
    </div>
    <div className="header-actions"><button className="user-avatar" onClick={startLogout} title={user.authProvider === 'mock' ? 'Mock Entra ID session' : `Signed in as ${user.email}`}>{user.initials}</button><button className="icon-button" onClick={onReset} aria-label="Start over" title="Start over"><Icon name="reset" size={18} /></button></div>
  </header>
}

function ModeTabs({ mode, onChange }: { mode: AppMode; onChange: (mode: AppMode) => void }) {
  return <nav className="mode-tabs" aria-label="Assistant mode">
    <button className={mode === 'notes' ? 'active' : ''} onClick={() => onChange('notes')}><Icon name="note" size={17}/>Notes</button>
    <button className={mode === 'brief' ? 'active' : ''} onClick={() => onChange('brief')}><Icon name="brief" size={17}/>Brief</button>
  </nav>
}

function Field({ label, value, onChange, multiline = false }: { label: string; value: string; onChange: (value: string) => void; multiline?: boolean }) {
  return <label className="field">
    <span>{label}</span>
    {multiline ? <textarea value={value} onChange={(e) => onChange(e.target.value)} rows={3}/> : <input value={value} onChange={(e) => onChange(e.target.value)} />}
  </label>
}

function NotesFlow({ resetKey, user }: { resetKey: number; user: AuthUser }) {
  const [step, setStep] = useState<NotesStep>('idle')
  const [elapsed, setElapsed] = useState(0)
  const [busy, setBusy] = useState(false)
  const [transcript, setTranscript] = useState('')
  const [questions, setQuestions] = useState<FollowUpQuestion[]>([])
  const [questionIndex, setQuestionIndex] = useState(0)
  const [answer, setAnswer] = useState('')
  const [summary, setSummary] = useState<MeetingSummary | null>(null)
  const [email, setEmail] = useState('')
  const [savedId, setSavedId] = useState('')
  const [entities, setEntities] = useState<EntityResolutionItem[]>([])
  const [pipeline, setPipeline] = useState<PipelineStatus | null>(null)
  const [revision, setRevision] = useState('')
  const [revisionError, setRevisionError] = useState('')
  const [saveError, setSaveError] = useState('')
  const [speaking, setSpeaking] = useState(false)
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null)
  const [audioUrl, setAudioUrl] = useState('')
  const [captureError, setCaptureError] = useState('')
  const [processingError, setProcessingError] = useState('')
  const [streamStatus, setStreamStatus] = useState<StreamStatus>('idle')
  const [liveTranscript, setLiveTranscript] = useState('')
  const [liveTranscriptFinal, setLiveTranscriptFinal] = useState(false)
  const [streamError, setStreamError] = useState('')
  const [voiceSessionId, setVoiceSessionId] = useState<string>()
  const mediaRef = useRef<MediaRecorder | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const voiceStreamRef = useRef<VoiceStreamController | null>(null)
  const chunksRef = useRef<Blob[]>([])

  const reset = () => {
    if (mediaRef.current?.state === 'recording') mediaRef.current.stop()
    streamRef.current?.getTracks().forEach((track) => track.stop())
    setStep('idle'); setElapsed(0); setBusy(false); setTranscript(''); setQuestions([])
    window.speechSynthesis?.cancel()
    setQuestionIndex(0); setAnswer(''); setSummary(null); setEmail(''); setSavedId(''); setEntities([]); setPipeline(null)
    setRevision(''); setRevisionError(''); setSaveError(''); setSpeaking(false)
    setAudioBlob(null); setAudioUrl(''); setCaptureError(''); setProcessingError(''); chunksRef.current = []
    void voiceStreamRef.current?.stop(); voiceStreamRef.current = null
    setStreamStatus('idle'); setLiveTranscript(''); setLiveTranscriptFinal(false); setStreamError(''); setVoiceSessionId(undefined)
  }
  useEffect(reset, [resetKey])
  useEffect(() => () => {
    if (mediaRef.current?.state === 'recording') mediaRef.current.stop()
    streamRef.current?.getTracks().forEach((track) => track.stop())
    void voiceStreamRef.current?.stop()
    window.speechSynthesis?.cancel()
  }, [])
  useEffect(() => {
    return () => { if (audioUrl) URL.revokeObjectURL(audioUrl) }
  }, [audioUrl])
  useEffect(() => {
    document.querySelector('.content-scroll')?.scrollTo({ top: 0, behavior: 'smooth' })
  }, [step])

  useEffect(() => {
    if (step !== 'recording') return
    const timer = window.setInterval(() => setElapsed((value) => value + 1), 1000)
    return () => window.clearInterval(timer)
  }, [step])

  async function connectVoiceStream(stream: MediaStream) {
    setStreamError('')
    try {
      const controller = await startVoiceStream(stream, {
        onStatus: setStreamStatus,
        onTranscript: (text, isFinal) => { setLiveTranscript(text); setLiveTranscriptFinal(isFinal) },
        onError: (message) => { setStreamError(message); setStreamStatus('degraded') },
      })
      voiceStreamRef.current = controller
      setVoiceSessionId(controller.sessionId)
    } catch (error) {
      setStreamStatus('degraded')
      setStreamError(error instanceof Error ? error.message : 'Live transcription could not be started.')
    }
  }

  async function retryVoiceStream() {
    if (!streamRef.current || streamRef.current.getTracks().every((track) => track.readyState === 'ended')) return
    await voiceStreamRef.current?.stop()
    voiceStreamRef.current = null
    await connectVoiceStream(streamRef.current)
  }

  async function beginRecording() {
    setElapsed(0)
    setCaptureError('')
    setProcessingError('')
    setAudioBlob(null)
    setAudioUrl('')
    setLiveTranscript('')
    setLiveTranscriptFinal(false)
    setStreamStatus('connecting')
    setStreamError('')
    setVoiceSessionId(undefined)
    chunksRef.current = []
    try {
      if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
        throw new Error('Recording is not supported')
      }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream
      const mimeType = preferredRecordingType()
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined)
      mediaRef.current = recorder
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) chunksRef.current.push(event.data)
      }
      recorder.onerror = () => {
        setCaptureError('Recording stopped because the browser reported an audio capture error.')
        stream.getTracks().forEach((track) => track.stop())
        setStep('idle')
      }
      recorder.start(250)
      setStep('recording')
      void connectVoiceStream(stream)
    } catch (error) {
      streamRef.current?.getTracks().forEach((track) => track.stop())
      setCaptureError(recordingErrorMessage(error))
    }
  }

  async function finishRecording() {
    const recorder = mediaRef.current
    if (!recorder || recorder.state !== 'recording') return
    const blob = await new Promise<Blob>((resolve) => {
      recorder.addEventListener('stop', () => {
        resolve(new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' }))
      }, { once: true })
      recorder.stop()
    })
    await voiceStreamRef.current?.stop()
    voiceStreamRef.current = null
    streamRef.current?.getTracks().forEach((track) => track.stop())
    if (!blob.size) {
      setCaptureError('No audio was captured. Please try recording again.')
      setStep('idle')
      return
    }
    setAudioBlob(blob)
    setAudioUrl(URL.createObjectURL(blob))
    setStep('recorded')
  }

  async function processRecording() {
    if (!audioBlob) return
    setBusy(true)
    setProcessingError('')
    try {
      const result = await submitVoiceNote(audioBlob, voiceSessionId)
      await acceptProcessingResult(result)
    } catch (error) {
      setProcessingError(error instanceof Error ? error.message : 'The recording could not be processed.')
    } finally {
      setBusy(false)
    }
  }

  async function useSampleNote() {
    setBusy(true)
    setProcessingError('')
    try {
      const result = await processVoiceNote()
      await acceptProcessingResult(result)
    } finally {
      setBusy(false)
    }
  }

  async function acceptProcessingResult(result: Awaited<ReturnType<typeof processVoiceNote>>) {
    const nextSummary = normalizeSummary(result.summary)
    const nextQuestions = normalizeQuestions(result.questions)
    setTranscript(result.transcript || liveTranscript)
    setQuestions(nextQuestions)
    setSummary(nextSummary)
    setEntities(await resolveMeetingEntities(nextSummary))
    setQuestionIndex(0)
    setStep(nextQuestions.length ? 'questions' : 'entities')
  }

  function updateSummary(key: keyof MeetingSummary, value: string) {
    setSummary((current) => current ? { ...current, [key]: value } : current)
  }

  function nextQuestion(skipped = false) {
    const current = questions[questionIndex]
    setQuestions((items) => items.map((item, i) => i === questionIndex ? { ...item, answer: skipped ? undefined : answer, skipped } : item))
    if (!skipped && answer.trim()) {
      const topic = current.topic.toLowerCase()
      const field: keyof MeetingSummary = topic.includes('compet') ? 'competitors' : topic.includes('next') ? 'actionItems' : topic.includes('driver') || topic.includes('need') ? 'dealSignals' : 'summary'
      setSummary((value) => value ? { ...value, [field]: value[field] ? `${value[field]}\n${answer.trim()}` : answer.trim() } : value)
    }
    setAnswer('')
    if (questionIndex + 1 >= questions.length) setStep('entities')
    else setQuestionIndex((index) => index + 1)
  }

  function selectEntityCandidate(itemId: string, candidateId: string) {
    setEntities((items) => items.map((item) => item.id === itemId ? { ...item, selectedId: candidateId, action: 'pending', resolvedAt: undefined } : item))
  }

  function decideEntity(itemId: string, action: 'confirmed' | 'removed') {
    setEntities((items) => items.map((item) => item.id === itemId ? { ...item, action, resolvedAt: new Date().toISOString() } : item))
  }

  function finishEntityResolution() {
    if (!summary) return
    const account = entities.find((item) => item.kind === 'account')
    const opportunity = entities.find((item) => item.kind === 'opportunity')
    const participants = entities.filter((item) => item.kind === 'participant')
    const accountCandidate = account?.candidates.find((candidate) => candidate.id === account.selectedId)
    const opportunityCandidate = opportunity?.candidates.find((candidate) => candidate.id === opportunity.selectedId)
    setSummary({
      ...summary,
      customer: accountCandidate?.label ?? summary.customer,
      opportunityId: opportunity?.action === 'removed' ? 'account' : opportunityCandidate?.id ?? 'account',
      opportunity: opportunity?.action === 'removed' ? 'Account-level CVR' : opportunityCandidate?.label ?? 'Account-level CVR',
      participants: participants.map((item) => {
        if (item.action === 'removed') return `${item.originalText} (unresolved mention retained as context)`
        return item.candidates.find((candidate) => candidate.id === item.selectedId)?.label ?? item.originalText
      }).join('; '),
    })
    setStep('review')
  }

  function speakSummary() {
    if (!summary || !('speechSynthesis' in window)) return
    if (speaking) {
      window.speechSynthesis.cancel()
      setSpeaking(false)
      return
    }
    const text = summaryFields.filter(({ key }) => summary[key]?.trim()).map(({ key, label }) => `${label}. ${summary[key]}`).join('. ')
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.onend = () => setSpeaking(false)
    utterance.onerror = () => setSpeaking(false)
    setSpeaking(true)
    window.speechSynthesis.speak(utterance)
  }

  async function applyRevision() {
    if (!summary || !revision.trim()) return
    setBusy(true); setRevisionError('')
    try {
      setSummary(normalizeSummary(await reviseVoiceSummary(summary, revision.trim())))
      setRevision('')
    } catch (error) {
      setRevisionError(error instanceof Error ? error.message : 'The requested change could not be applied.')
    } finally {
      setBusy(false)
    }
  }

  async function save() {
    if (!summary) return
    setBusy(true); setSaveError('')
    try {
      const result = await createCvr(summary, entities)
      const draft = await generateFollowUpEmail(summary)
      setSavedId(result.id)
      setPipeline(result.pipeline)
      setEmail(draft)
      setStep('saved')
    } catch (error) {
      setSaveError(error instanceof Error ? error.message : 'CVR creation failed. Your draft is preserved and can be retried.')
    } finally {
      setBusy(false)
    }
  }

  if (step === 'idle') return <section className="screen landing-screen">
    <div className="hero-icon"><Icon name="mic" size={38}/></div>
    <p className="eyebrow">Post-meeting notes</p>
    <h1>Capture the conversation while it’s fresh</h1>
    <p className="lead">Record a quick voice debrief. The assistant will organize it, fill gaps, and prepare a CVR draft for your review.</p>
    <div className="session-strip"><span className="user-avatar small">{user.initials}</span><div><strong>{user.displayName}</strong><small>{user.authProvider === 'entra-id' ? 'Authenticated with Entra ID' : 'Prototype Entra ID session'}</small></div><span className={`environment-badge ${backendMode}`}>{backendMode === 'aws' ? 'AWS' : 'Mock'}</span></div>
    <div className="privacy-note"><span className="status-dot" /> No CVR is saved until you confirm</div>
    {captureError && <p className="error-message" role="alert">{captureError}</p>}
    <button className="primary big" onClick={beginRecording}><Icon name="mic"/>Start recording</button>
    <button className="text-button" onClick={useSampleNote} disabled={busy}>{busy ? 'Loading sample…' : 'Use sample note'}</button>
  </section>

  if (step === 'recording') return <section className="screen recording-screen">
    <p className="eyebrow">Describe your meeting</p>
    <h1>I’m listening</h1>
    <div className="record-orb"><Icon name="mic" size={34}/></div>
    <Waveform active/>
    <strong className="timer">{formatTime(elapsed)}</strong>
    <div className={`stream-status ${streamStatus}`}><span/><div><strong>{streamLabels[streamStatus]}</strong><small>{backendMode === 'mock' ? 'Prototype event stream' : 'PCM 16 kHz · WebSocket · AWS Transcribe'}</small></div></div>
    <div className="live-transcript"><div><span className="live-dot"/>Live transcript {liveTranscriptFinal && <b>final</b>}</div><p>{liveTranscript || (streamStatus === 'connecting' ? 'Opening a secure voice session…' : 'Start speaking; partial transcript events will appear here.')}</p></div>
    {streamError && <div className="stream-error" role="alert"><span>{streamError}</span><button className="secondary compact" onClick={retryVoiceStream}>Retry stream</button></div>}
    <p className="hint">Mention the customer, participants, products, needs, timing, competitors, blockers, and next steps.</p>
    <button className="primary danger" onClick={finishRecording}>Stop recording</button>
  </section>

  if (step === 'recorded' && audioBlob) return <section className="screen recording-review-screen">
    <div className="recorded-mark"><Icon name="check" size={30}/></div>
    <p className="eyebrow">Recording ready</p>
    <h1>Review your voice note</h1>
    <p className="lead">Listen before processing, or record it again if something was missed.</p>
    <div className="audio-card">
      <audio controls preload="metadata" src={audioUrl}>Your browser does not support audio playback.</audio>
      <div className="recording-meta">
        <span>{formatTime(elapsed)}</span>
        <span>{Math.max(1, Math.round(audioBlob.size / 1024))} KB</span>
        <span>{audioBlob.type.split(';')[0].replace('audio/', '').toUpperCase()}</span>
      </div>
      <p className="upload-state"><span className="status-dot" />{voiceApiMode === 'server' ? 'Ready to send securely to the configured server' : 'Demo mode: processing uses sample AI results'}</p>
      {liveTranscript && <details className="captured-transcript"><summary>Captured live transcript</summary><p>{liveTranscript}</p></details>}
      <a className="download-link" href={audioUrl} download="sales-voice-note.webm">Download recording</a>
    </div>
    {processingError && <p className="error-message" role="alert">{processingError}</p>}
    <div className="recording-actions">
      <button className="secondary" onClick={beginRecording} disabled={busy}>Retake</button>
      <button className="primary" onClick={processRecording} disabled={busy}>{busy ? 'Processing…' : 'Process voice note'}<Icon name="spark" size={18}/></button>
    </div>
  </section>

  if (busy && !summary) return <section className="screen recording-screen">
    <p className="eyebrow">Processing voice note</p>
    <h1>Turning your note into a summary…</h1>
    <div className="record-orb processing"><Icon name="spark" size={34}/></div>
    <Waveform/>
    <strong className="timer">Finding key details</strong>
    <p className="hint">The agent is extracting CRM-critical details and preparing follow-up questions.</p>
  </section>

  if (step === 'questions' && summary) {
    const current = questions[questionIndex]
    return <section className="screen conversation-screen">
      <div className="progress-row"><span>Completing your note</span><strong>{questionIndex + 1} of {questions.length}</strong></div>
      <div className="progress"><span style={{ width: `${((questionIndex + 1) / questions.length) * 100}%` }} /></div>
      <details className="transcript-card">
        <summary>Raw transcript</summary>
        <p>{transcript}</p>
      </details>
      <SummarySnapshot summary={summary} speaking={speaking} onSpeak={speakSummary}/>
      <div className="agent-message">
        <div className="avatar"><Icon name="spark" size={18}/></div>
        <div><small>{current.topic}</small><p>{current.prompt}</p></div>
      </div>
      <label className="answer-box">
        <span>Your answer</span>
        <textarea rows={4} value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder="Type your answer…"/>
        <button className="mic-mini" disabled aria-label="Voice answers require a backend contract" title="Voice answers will be enabled when the backend contract is available"><Icon name="mic" size={18}/></button>
      </label>
      <div className="button-row">
        <button className="secondary" onClick={() => nextQuestion(true)}><Icon name="skip" size={17}/>Skip</button>
        <button className="primary" onClick={() => nextQuestion(false)} disabled={!answer.trim()}>Continue<Icon name="chevron" size={17}/></button>
      </div>
      <button className="text-button" onClick={() => setStep('entities')}>Finalize now</button>
    </section>
  }

  if (step === 'entities' && summary) {
    const ready = entities.length > 0 && entities.every((item) => item.action !== 'pending') && entities.filter((item) => item.required).every((item) => item.action === 'confirmed' && item.selectedId)
    return <section className="screen entity-screen">
      <p className="eyebrow">Entity resolution</p>
      <h1>Confirm CRM matches</h1>
      <p className="lead">Review how each mention was resolved. Required records must be confirmed before CVR creation.</p>
      <div className="demo-banner"><Icon name="alert" size={17}/><span>{entityApiMode === 'mock' ? <><strong>Prototype candidates</strong> — replace with CRM entity resolution API results.</> : <><strong>CRM candidates</strong> — returned by the configured entity resolution service.</>}</span></div>
      {entities.map((item) => <article className={`entity-card ${item.action}`} key={item.id}>
        <div className="entity-heading"><div><small>{item.label}{item.required && ' · required'}</small><h2>{item.originalText}</h2></div><span className={`decision-badge ${item.action}`}>{item.action}</span></div>
        <div className="candidate-list">
          {item.candidates.map((candidate) => <label className={`candidate ${item.selectedId === candidate.id ? 'selected' : ''}`} key={candidate.id}>
            <input type="radio" name={item.id} value={candidate.id} checked={item.selectedId === candidate.id} onChange={() => selectEntityCandidate(item.id, candidate.id)}/>
            <span><strong>{candidate.label}</strong><small>{candidate.detail}</small><small>{candidate.sourceSystem ? `${candidate.sourceSystem} · ` : ''}{candidate.matchMethod}</small></span>
            <b className={candidate.confidence < 75 ? 'low' : ''}>{candidate.confidence}%</b>
          </label>)}
        </div>
        <div className="entity-actions">
          {!item.required && <button className="text-button remove" onClick={() => decideEntity(item.id, 'removed')}>Remove mapping</button>}
          <button className="secondary compact" disabled={!item.selectedId} onClick={() => decideEntity(item.id, 'confirmed')}><Icon name="check" size={15}/>Confirm match</button>
        </div>
      </article>)}
      <div className="sticky-action"><button className="primary big" disabled={!ready} onClick={finishEntityResolution}>Continue to CVR review<Icon name="chevron"/></button></div>
    </section>
  }

  if (step === 'review' && summary) {
    const capturedFields = summaryFields.filter(({ key }) => summary[key]?.trim())
    const missingFields = summaryFields.filter(({ key }) => !summary[key]?.trim())
    return <section className="screen review-screen">
    <div className="screen-heading"><div><p className="eyebrow">Review before saving</p><h1>CVR draft</h1></div><span className="draft-badge">Draft</span></div>
    <div className="confidence"><Icon name="spark" size={17}/><span><strong>Entities resolved</strong> — verify extracted intelligence before saving</span></div>
    <SummarySnapshot summary={summary} speaking={speaking} onSpeak={speakSummary}/>
    <div className="form-section">
      <div className="section-title-row"><h2>Resolved CRM records</h2><button className="text-button" onClick={() => setStep('entities')}>Change</button></div>
      <div className="resolved-record"><small>Customer account</small><strong>{summary.customer}</strong></div>
      <div className="resolved-record"><small>Opportunity</small><strong>{summary.opportunity}</strong></div>
      <div className="resolved-record"><small>Participants</small><strong>{summary.participants}</strong></div>
    </div>
    <div className="revision-card"><div className="qa-title"><Icon name="spark"/><div><h2>Tell the agent what to change</h2><p>Example: “Timeline is Q4” or “Competitors are SLB and NOV”.</p></div></div>
      <label className="ask-box"><input value={revision} onChange={(e) => setRevision(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && applyRevision()} placeholder="Describe a correction…"/><button onClick={applyRevision} disabled={!revision.trim() || busy}><Icon name="send" size={18}/></button></label>
      {revisionError && <p className="error-message" role="alert">{revisionError}</p>}
    </div>
    <div className="form-section"><h2>Captured meeting intelligence</h2>
      <label className="field"><span>Sentiment</span><select value={summary.sentiment} onChange={(e) => updateSummary('sentiment', e.target.value)}><option>Positive</option><option>Mixed</option><option>Negative</option></select></label>
      {capturedFields.map(({ key, label, multiline }) => <Field key={key} label={label} value={summary[key]} onChange={(value) => updateSummary(key, value)} multiline={multiline}/>)}
      {missingFields.length > 0 && <details className="missing-fields"><summary>Add missing details ({missingFields.length})</summary><div>{missingFields.map(({ key, label, multiline }) => <Field key={key} label={label} value={summary[key]} onChange={(value) => updateSummary(key, value)} multiline={multiline}/>)}</div></details>}
    </div>
    {saveError && <p className="error-message" role="alert">{saveError}</p>}
    <div className="sticky-action"><button className="primary big" onClick={save} disabled={busy}>{busy ? 'Saving…' : saveError ? 'Retry CVR save' : 'Confirm & save CVR'}<Icon name="check"/></button></div>
  </section>
  }

  return <section className="screen saved-screen">
    <div className="success-mark"><Icon name="check" size={38}/></div>
    <p className="eyebrow">Saved to Deal Machine</p>
    <h1>CVR created successfully</h1>
    <p className="record-id">{savedId}</p>
    {pipeline && <div className="pipeline-card">
      <div className="pipeline-title"><div><small>{cvrApiMode === 'mock' ? 'Demo processing status' : 'Processing status'}</small><h2>Databricks persistence</h2></div><span className="decision-badge confirmed">completed</span></div>
      <div className="pipeline-row"><span><Icon name="check" size={15}/>Bronze transcript chunks</span><strong>{pipeline.bronze.chunks}</strong></div>
      <div className="pipeline-row"><span><Icon name="check" size={15}/>Silver records created</span><strong>{pipeline.silver.created}</strong></div>
      <div className="pipeline-row"><span>Updated</span><strong>{pipeline.silver.updated}</strong></div>
      <div className="pipeline-row rejected"><span>Rejected with validation reason</span><strong>{pipeline.silver.rejected}</strong></div>
      {cvrApiMode === 'mock' && <p>Counts are mock data until Bronze/Silver status and audit APIs are connected.</p>}
    </div>}
    <div className="email-card">
      <div className="email-heading"><div><small>Internal follow-up</small><h2>Email draft</h2></div><Icon name="edit"/></div>
      <textarea value={email} onChange={(e) => setEmail(e.target.value)} rows={14}/>
      <button className="secondary full" disabled title="Outlook sending is a TBC feature"><Icon name="send"/>Send with Outlook — coming later</button>
    </div>
    <button className="primary big" onClick={reset}>Start another note</button>
  </section>
}

function BriefFlow({ resetKey }: { resetKey: number }) {
  const [context, setContext] = useState('Prepare me for a meeting with Chevron about ESP opportunities')
  const [brief, setBrief] = useState<CustomerBrief | null>(null)
  const [busy, setBusy] = useState(false)
  const [question, setQuestion] = useState('')
  const [messages, setMessages] = useState<{ question: string; answer: string }[]>([])
  useEffect(() => { setBrief(null); setMessages([]); setBusy(false) }, [resetKey])
  useEffect(() => {
    document.querySelector('.content-scroll')?.scrollTo({ top: 0, behavior: 'smooth' })
  }, [brief])

  async function createBrief() { setBusy(true); setBrief(await createCustomerBrief(context)); setBusy(false) }
  async function ask() {
    if (!question.trim() || !brief) return
    const prompt = question
    setQuestion(''); setBusy(true)
    const answer = await askCustomerBrief(prompt, brief)
    setMessages((items) => [...items, { question: prompt, answer }]); setBusy(false)
  }

  if (!brief) return <section className="screen landing-screen brief-landing">
    <div className="hero-icon"><Icon name="brief" size={38}/></div>
    <p className="eyebrow">Pre-meeting brief</p>
    <h1>Walk in prepared</h1>
    <p className="lead">Tell the assistant which meeting you’re preparing for. It will bring together recent notes, CRM opportunities, and pricing context.</p>
    <label className="context-box"><span>Meeting context</span><textarea rows={5} value={context} onChange={(e) => setContext(e.target.value)} /><button className="mic-mini" disabled aria-label="Voice context requires a backend contract" title="Voice context will be enabled when the backend contract is available"><Icon name="mic" size={18}/></button></label>
    <button className="primary big" onClick={createBrief} disabled={!context.trim() || busy}>{busy ? 'Preparing brief…' : 'Generate briefing'}<Icon name="spark"/></button>
  </section>

  return <section className="screen brief-screen">
    <p className="eyebrow">Customer briefing</p><h1>{brief.title}</h1>
    <div className="pulse-row"><span className={`sentiment ${brief.sentiment.toLowerCase()}`}>{brief.sentiment}</span><span>Account pulse</span></div>
    <BriefSection title="Context" items={brief.context}/>
    <BriefSection title="Stakeholders" items={brief.stakeholders}/>
    <BriefSection title="Open items" items={brief.openItems}/>
    <div className="brief-block"><h2>Opportunities</h2>{brief.opportunities.map((item) => <div className="opportunity" key={item.id}><div><strong>{item.name}</strong><small>{item.stage}</small></div><span>{item.value}</span></div>)}</div>
    <BriefSection title="Pricing intelligence" items={brief.pricing}/>
    <div className="qa-section"><div className="qa-title"><Icon name="spark"/><div><h2>Ask about this brief</h2><p>Answers route across notes, CRM, and Genie.</p></div></div>
      {messages.map((message, i) => <div className="qa-message" key={i}><p className="user-question"><Icon name="user" size={15}/>{message.question}</p><p>{message.answer}</p></div>)}
      <label className="ask-box"><input value={question} onChange={(e) => setQuestion(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && ask()} placeholder="Ask about risks, competitors, pricing…"/><button onClick={ask} disabled={!question.trim() || busy}><Icon name="send" size={18}/></button></label>
    </div>
  </section>
}

function BriefSection({ title, items }: { title: string; items: string[] }) {
  return <div className="brief-block"><h2>{title}</h2><ul>{items.map((item) => <li key={item}>{item}</li>)}</ul></div>
}

export default function App() {
  const [mode, setMode] = useState<AppMode>('notes')
  const [resetKey, setResetKey] = useState(0)
  const [user, setUser] = useState<AuthUser | null | undefined>(undefined)
  const [sessionError, setSessionError] = useState('')

  useEffect(() => {
    getSessionUser().then(setUser).catch((error) => {
      setSessionError(error instanceof Error ? error.message : 'Unable to verify the user session.')
      setUser(null)
    })
  }, [])

  if (user === undefined) return <div className="auth-shell"><div className="auth-card"><div className="brand-mark"><span/><span/></div><h1>Checking secure session…</h1><p>Connecting to the AWS-hosted application.</p></div></div>
  if (!user) return <div className="auth-shell"><div className="auth-card"><div className="brand-mark"><span/><span/></div><p className="eyebrow">OmniSource Commercial Assistant</p><h1>Sign in to continue</h1><p>Use your Baker Hughes Entra ID account to start a protected voice session.</p>{sessionError && <p className="error-message">{sessionError}</p>}<button className="primary big" onClick={startEntraLogin}><Icon name="user"/>Sign in with Entra ID</button></div></div>

  return <div className="app-shell">
    <main className="app-container">
      <Header user={user} onReset={() => setResetKey((key) => key + 1)} />
      <ModeTabs mode={mode} onChange={setMode}/>
      <div className="content-scroll">{mode === 'notes' ? <NotesFlow resetKey={resetKey} user={user}/> : <BriefFlow resetKey={resetKey}/>}</div>
    </main>
  </div>
}
