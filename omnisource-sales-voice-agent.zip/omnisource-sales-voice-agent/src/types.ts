export type AppMode = 'notes' | 'brief'
export type NotesStep = 'idle' | 'recording' | 'recorded' | 'questions' | 'entities' | 'review' | 'saved'
export type StreamStatus = 'idle' | 'connecting' | 'connected' | 'reconnecting' | 'degraded' | 'closed'

export interface AuthUser {
  id: string
  displayName: string
  email: string
  initials: string
  authProvider: 'entra-id' | 'mock'
}

export interface FollowUpQuestion {
  id: string
  prompt: string
  topic: string
  answer?: string
  skipped?: boolean
}

export interface MeetingSummary {
  customer: string
  opportunityId: string
  opportunity: string
  sentiment: 'Positive' | 'Mixed' | 'Negative'
  participants: string
  products: string
  dealSignals: string
  decisionMakers: string
  statedNeeds: string
  timeline: string
  objections: string
  actionItems: string
  blockers: string
  competitors: string
  competitorStrengths: string
  competitorWeaknesses: string
  decisionProcess: string
  procurementConstraints: string
  incumbentFootprint: string
  nextCommitment: string
  summary: string
}

export interface EntityCandidate {
  id: string
  label: string
  detail: string
  matchMethod: string
  confidence: number
  sourceSystem?: string
}

export interface EntityResolutionItem {
  id: string
  kind: 'account' | 'opportunity' | 'participant'
  label: string
  originalText: string
  required: boolean
  candidates: EntityCandidate[]
  selectedId: string
  action: 'pending' | 'confirmed' | 'removed'
  resolvedAt?: string
}

export interface PipelineStatus {
  bronze: { state: 'completed' | 'pending'; chunks: number }
  silver: { state: 'completed' | 'pending'; created: number; updated: number; rejected: number }
  auditUrl?: string
}

export interface VoiceProcessingResult {
  transcript: string
  questions: FollowUpQuestion[]
  summary: MeetingSummary
}

export interface Opportunity {
  id: string
  name: string
  value: string
  stage: string
}

export interface CustomerBrief {
  customer: string
  title: string
  context: string[]
  sentiment: 'Positive' | 'Mixed' | 'Negative'
  stakeholders: string[]
  openItems: string[]
  opportunities: Opportunity[]
  pricing: string[]
  competitor: string
}
