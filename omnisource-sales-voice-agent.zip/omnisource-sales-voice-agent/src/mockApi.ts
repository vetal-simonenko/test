import type { CustomerBrief, EntityResolutionItem, MeetingSummary, Opportunity, PipelineStatus, VoiceProcessingResult } from './types'

const delay = (ms = 650) => new Promise((resolve) => window.setTimeout(resolve, ms))

export const opportunities: Opportunity[] = [
  { id: 'opp-101', name: 'Permian ESP Optimization', value: '$1.2M', stage: 'Proposal' },
  { id: 'opp-102', name: 'Guyana Offshore Completions', value: '$1.1M', stage: 'Qualification' },
]

export const sampleTranscript =
  "I'm just out of a meeting with ExxonMobil. They are interested in our ESP solution for a group of wells coming online in the next two to three months. We need to demonstrate stronger gas-handling performance than the competition."

export async function processVoiceNote(_audio?: Blob): Promise<VoiceProcessingResult> {
  await delay(900)
  return {
    transcript: sampleTranscript,
    questions: [
      { id: 'q1', topic: 'Business driver', prompt: "What's driving their interest in ESPs right now?" },
      { id: 'q2', topic: 'Competition', prompt: 'Who are the main competitors they are comparing us against?' },
      { id: 'q3', topic: 'Next step', prompt: 'What is the next customer commitment and who owns it?' },
    ],
    summary: {
      customer: 'ExxonMobil',
      opportunityId: 'opp-102',
      opportunity: 'Guyana Offshore Completions',
      sentiment: 'Positive',
      participants: 'Sales representative; customer engineering team',
      products: 'Electrical Submersible Pumps (ESP)',
      dealSignals: 'Several wells expected online within 2–3 months',
      decisionMakers: 'Customer production and engineering leadership',
      statedNeeds: 'Reliable gas handling and proof of performance',
      timeline: 'Next 2–3 months',
      objections: 'Needs evidence of differentiation against competitors',
      actionItems: 'Prepare gas-handling performance comparison and schedule technical review',
      blockers: 'Competitive proof points are not yet packaged',
      competitors: 'Halliburton; SLB',
      competitorStrengths: 'Established field references and incumbent relationships',
      competitorWeaknesses: 'Customer has not seen sufficient evidence of differentiated gas handling',
      decisionProcess: 'Engineering validation followed by production leadership approval',
      procurementConstraints: '',
      incumbentFootprint: 'Halliburton is the current incumbent on part of the field',
      nextCommitment: 'Technical performance review to be scheduled this week',
      summary: 'Customer is evaluating ESP options for upcoming wells. The strongest path forward is to demonstrate gas-handling performance and provide clear competitive evidence.',
    },
  }
}

export async function resolveEntities(summary: MeetingSummary): Promise<EntityResolutionItem[]> {
  await delay(450)
  return [
    {
      id: 'account', kind: 'account', label: 'Customer account', originalText: summary.customer, required: true,
      selectedId: 'acc-001', action: 'pending',
      candidates: [
        { id: 'acc-001', label: 'ExxonMobil Corporation', detail: 'CRM Account · Global', matchMethod: 'Exact normalized name', confidence: 96, sourceSystem: 'Salesforce CRM' },
        { id: 'acc-014', label: 'ExxonMobil Guyana Ltd.', detail: 'CRM Account · Guyana', matchMethod: 'Account hierarchy match', confidence: 82, sourceSystem: 'Salesforce CRM' },
      ],
    },
    {
      id: 'opportunity', kind: 'opportunity', label: 'Opportunity', originalText: summary.opportunity, required: false,
      selectedId: summary.opportunityId, action: 'pending',
      candidates: opportunities.map((item, index) => ({ id: item.id, label: item.name, detail: `${item.stage} · ${item.value}`, matchMethod: index ? 'Account + product fuzzy match' : 'Product line match', confidence: index ? 74 : 61, sourceSystem: 'Salesforce CRM' })),
    },
    {
      id: 'participant-sales', kind: 'participant', label: 'Participant', originalText: 'Sales representative', required: false,
      selectedId: 'usr-118', action: 'pending',
      candidates: [{ id: 'usr-118', label: 'Current signed-in sales rep', detail: 'Internal user · Sales', matchMethod: 'Authenticated user ID', confidence: 100, sourceSystem: 'Microsoft Entra ID' }],
    },
    {
      id: 'participant-customer', kind: 'participant', label: 'Participant', originalText: 'Customer engineering team', required: false,
      selectedId: '', action: 'pending',
      candidates: [{ id: 'con-340', label: 'Alex Morgan', detail: 'Production Engineering · ExxonMobil', matchMethod: 'Name and account fuzzy match', confidence: 58, sourceSystem: 'Salesforce CRM' }],
    },
  ]
}

export async function reviseMeetingSummary(summary: MeetingSummary, instruction: string): Promise<MeetingSummary> {
  await delay(600)
  const next = { ...summary }
  const valueAfter = (pattern: RegExp) => instruction.match(pattern)?.[1]?.trim().replace(/[.]+$/, '')
  const customer = valueAfter(/(?:customer|account)\s+(?:is|to)\s+(.+)/i)
  const competitors = valueAfter(/competitors?\s+(?:are|is|to)\s+(.+)/i)
  const timeline = valueAfter(/timeline\s+(?:is|to)\s+(.+)/i)
  const commitment = valueAfter(/(?:next meeting|next milestone|next commitment)\s+(?:is|to)\s+(.+)/i)
  if (customer) next.customer = customer
  else if (competitors) next.competitors = competitors
  else if (timeline) next.timeline = timeline
  else if (commitment) next.nextCommitment = commitment
  else next.summary = `${next.summary}\nRevision requested: ${instruction.trim()}`
  return next
}

export async function saveCvr(summary: MeetingSummary, _resolution: EntityResolutionItem[] = []): Promise<{ id: string; pipeline: PipelineStatus }> {
  await delay(800)
  return {
    id: `CVR-${summary.opportunityId === 'account' ? 'ACC' : 'OPP'}-2048`,
    pipeline: {
      bronze: { state: 'completed', chunks: 4 },
      silver: { state: 'completed', created: 12, updated: 2, rejected: 1 },
    },
  }
}

export async function generateEmail(summary: MeetingSummary): Promise<string> {
  await delay(500)
  return `Subject: ExxonMobil ESP opportunity — meeting follow-up\n\nTeam,\n\nWe had a positive discussion with ExxonMobil regarding ESP requirements for wells expected online in the next two to three months. The customer needs confidence in gas-handling performance and a clear comparison with competing solutions.\n\nNext steps:\n• Prepare the gas-handling performance comparison.\n• Confirm technical review attendees and timing.\n• Share relevant proof points and references.\n\nOwner: Sales team\nTiming: This week\n\nPlease add any missing context before this is shared internally.`
}

export async function generateBrief(context: string): Promise<CustomerBrief> {
  await delay(950)
  const customer = /chevron/i.test(context) ? 'Chevron' : 'ExxonMobil'
  return {
    customer,
    title: `Visit Preparation Note — ${customer}`,
    context: [
      'Recent discussions focused on ESP performance and upcoming field activity.',
      'Customer interest is positive, but competitive differentiation remains important.',
      'A technical follow-up was requested with production and engineering stakeholders.',
    ],
    sentiment: 'Mixed',
    stakeholders: ['Operations lead — decision influencer', 'Production engineer — technical evaluator', 'Account manager — relationship owner'],
    openItems: ['Confirm well schedule', 'Provide gas-handling evidence', 'Align next technical workshop'],
    opportunities,
    pricing: ['Current opportunity value: $1.1M', 'Pricing position requires validation in Genie'],
    competitor: 'Halliburton is the primary competitive threat based on recent notes.',
  }
}

export async function answerBriefQuestion(question: string, brief: CustomerBrief): Promise<string> {
  await delay(550)
  if (/compet|threat|risk/i.test(question)) return brief.competitor
  if (/price|revenue|value/i.test(question)) return `${brief.pricing.join('. ')}.`
  if (/stakeholder|who/i.test(question)) return brief.stakeholders.join('; ')
  if (/next|action|open/i.test(question)) return `Recommended focus: ${brief.openItems.join('; ')}.`
  return `Based on the available notes and CRM context, focus the conversation on ${brief.openItems[0].toLowerCase()} and validate the customer's decision timeline.`
}
