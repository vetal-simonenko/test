import { saveCvr } from '../mockApi'
import type { EntityResolutionItem, MeetingSummary, PipelineStatus } from '../types'
import { configuredUrl } from './runtimeConfig'

const cvrApiUrl = configuredUrl(import.meta.env.VITE_CVR_API_URL, '/api/cvrs')

export const cvrApiMode: 'server' | 'mock' = cvrApiUrl ? 'server' : 'mock'

export async function createCvr(summary: MeetingSummary, resolution: EntityResolutionItem[]): Promise<{ id: string; pipeline: PipelineStatus }> {
  if (!cvrApiUrl) return saveCvr(summary, resolution)
  const response = await fetch(cvrApiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({ summary, entityResolution: resolution }),
  })
  if (!response.ok) throw new Error(`CVR creation failed (${response.status})`)
  const result: unknown = await response.json()
  if (!result || typeof result !== 'object' || typeof (result as { id?: unknown }).id !== 'string') {
    throw new Error('CVR response does not match the expected schema')
  }
  const data = result as { id: string; pipeline?: PipelineStatus }
  return {
    id: data.id,
    pipeline: data.pipeline ?? {
      bronze: { state: 'pending', chunks: 0 },
      silver: { state: 'pending', created: 0, updated: 0, rejected: 0 },
    },
  }
}
