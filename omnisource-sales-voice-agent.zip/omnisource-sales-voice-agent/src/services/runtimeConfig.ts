const trimSlash = (value: string) => value.replace(/\/+$/, '')

export const backendBaseUrl = trimSlash(import.meta.env.VITE_BACKEND_BASE_URL?.trim() || '')
export const backendMode: 'aws' | 'mock' = backendBaseUrl ? 'aws' : 'mock'

export function backendUrl(path: string) {
  if (!backendBaseUrl) return ''
  return `${backendBaseUrl}${path.startsWith('/') ? path : `/${path}`}`
}

export function configuredUrl(legacyValue: string | undefined, gatewayPath: string) {
  return legacyValue?.trim() || backendUrl(gatewayPath)
}
