import type { StreamStatus } from '../types'
import { backendMode, backendUrl } from './runtimeConfig'

type StreamCallbacks = {
  onStatus: (status: StreamStatus) => void
  onTranscript: (text: string, isFinal: boolean) => void
  onError: (message: string) => void
}

export type VoiceStreamController = {
  mode: 'aws' | 'mock'
  sessionId?: string
  stop: () => Promise<void>
}

function downsampleToPcm16(input: Float32Array, inputRate: number, outputRate = 16000) {
  const ratio = inputRate / outputRate
  const length = Math.max(1, Math.round(input.length / ratio))
  const output = new Int16Array(length)
  for (let index = 0; index < length; index += 1) {
    const start = Math.floor(index * ratio)
    const end = Math.min(input.length, Math.floor((index + 1) * ratio))
    let total = 0
    for (let source = start; source < end; source += 1) total += input[source]
    const sample = Math.max(-1, Math.min(1, total / Math.max(1, end - start)))
    output[index] = sample < 0 ? sample * 0x8000 : sample * 0x7fff
  }
  return output.buffer
}

async function startMockStream(callbacks: StreamCallbacks): Promise<VoiceStreamController> {
  callbacks.onStatus('connecting')
  const transcript = [
    'I’m just out of a customer meeting.',
    ' They are evaluating ESP solutions for upcoming wells.',
    ' The next step is a technical performance review.',
  ]
  let current = ''
  let stopped = false
  const timers: number[] = []
  callbacks.onStatus('connected')
  transcript.forEach((part, index) => {
    timers.push(window.setTimeout(() => {
      if (stopped) return
      current += part
      callbacks.onTranscript(current, index === transcript.length - 1)
    }, 900 * (index + 1)))
  })
  return {
    mode: 'mock',
    sessionId: `mock-${Date.now()}`,
    stop: async () => {
      stopped = true
      timers.forEach(window.clearTimeout)
      callbacks.onStatus('closed')
    },
  }
}

export async function startVoiceStream(stream: MediaStream, callbacks: StreamCallbacks): Promise<VoiceStreamController> {
  if (backendMode === 'mock') return startMockStream(callbacks)

  callbacks.onStatus('connecting')
  const sessionResponse = await fetch(backendUrl('/api/voice/sessions'), {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ encoding: 'pcm_s16le', sampleRate: 16000, channels: 1 }),
  })
  if (!sessionResponse.ok) throw new Error(`Unable to create voice session (${sessionResponse.status})`)
  const session = await sessionResponse.json() as { websocketUrl?: string; sessionId?: string }
  if (!session.websocketUrl) throw new Error('Voice session response did not include websocketUrl')

  const socket = new WebSocket(session.websocketUrl)
  socket.binaryType = 'arraybuffer'
  const audioContext = new AudioContext()
  if (audioContext.state === 'suspended') await audioContext.resume()
  const source = audioContext.createMediaStreamSource(stream)
  const processor = audioContext.createScriptProcessor(4096, 1, 1)
  const silentGain = audioContext.createGain()
  silentGain.gain.value = 0
  let stopped = false

  processor.onaudioprocess = (event) => {
    if (socket.readyState !== WebSocket.OPEN) return
    socket.send(downsampleToPcm16(event.inputBuffer.getChannelData(0), audioContext.sampleRate))
  }
  source.connect(processor)
  processor.connect(silentGain)
  silentGain.connect(audioContext.destination)

  socket.onopen = () => callbacks.onStatus('connected')
  socket.onmessage = (event) => {
    try {
      const message = JSON.parse(String(event.data)) as { type?: string; text?: string; isFinal?: boolean; message?: string }
      if (message.type === 'transcript' && message.text) callbacks.onTranscript(message.text, Boolean(message.isFinal))
      if (message.type === 'reconnecting') callbacks.onStatus('reconnecting')
      if (message.type === 'error') callbacks.onError(message.message || 'Streaming transcription failed.')
    } catch {
      callbacks.onError('The voice stream returned an unsupported event.')
    }
  }
  socket.onerror = () => callbacks.onError('The live transcription connection was interrupted.')
  socket.onclose = () => { if (!stopped) callbacks.onStatus('degraded') }

  return {
    mode: 'aws',
    sessionId: session.sessionId,
    stop: async () => {
      stopped = true
      processor.disconnect(); source.disconnect(); silentGain.disconnect()
      await audioContext.close()
      if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify({ type: 'stop', sessionId: session.sessionId }))
      socket.close(1000, 'recording-complete')
      callbacks.onStatus('closed')
    },
  }
}
