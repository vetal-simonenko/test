import { answerBriefQuestion as mockAnswer, generateBrief as mockBrief, generateEmail as mockEmail } from '../mockApi'
import type { CustomerBrief, MeetingSummary } from '../types'
import { backendMode, backendUrl } from './runtimeConfig'

async function postJson<T>(path: string, body: unknown): Promise<T> {
  const response = await fetch(backendUrl(path), {
    method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  })
  if (!response.ok) throw new Error(`Backend request failed (${response.status})`)
  return response.json() as Promise<T>
}

export async function generateFollowUpEmail(summary: MeetingSummary) {
  return backendMode === 'mock' ? mockEmail(summary) : postJson<string>('/api/follow-up/draft', { summary })
}

export async function createCustomerBrief(context: string) {
  return backendMode === 'mock' ? mockBrief(context) : postJson<CustomerBrief>('/api/briefs', { context })
}

export async function askCustomerBrief(question: string, brief: CustomerBrief) {
  return backendMode === 'mock' ? mockAnswer(question, brief) : postJson<string>('/api/briefs/questions', { question, brief })
}
