# OmniSource Commercial Assistant — frontend prototype

Mobile-first React 19 prototype based on the Sales Voice Agent POC, epic 383203, its child features, and the OmniSource Enterprise Architecture Design v1.4.

## Run locally

```bash
npm install
npm run dev
```

Microphone capture requires browser permission and a secure context (`localhost` during development or HTTPS when deployed).

## Implemented flows

- Feature 383230: real browser audio capture with timer, playback, metadata, download, retake, processing state, permission/error handling, transcript, structured summary, dynamic follow-up questions, skip, and early finalize.
- Architecture v1.4: Entra-aware application session, AWS gateway boundary, PCM signed-16-bit/16 kHz mono streaming over a short-lived WebSocket, live transcript events, connection/reconnection/degraded states, retry, and local recording fallback.
- Extended voice-capture stories: latest-summary panel, browser text-to-speech, natural-language correction boundary, hidden missing fields, maximum-five/duplicate-topic question guardrails, and the expanded CRM-critical field set.
- Feature 383232: dedicated Account/Opportunity/Participant entity resolution with match method, confidence, confirm/remove decisions, a required Account gate, editable CVR review, explicit confirmation, and mocked Deal Machine save.
- Feature 383235: editable internal follow-up email draft.
- Feature 383234: pre-meeting context input, customer briefing, opportunities, pricing context, and follow-up Q&A.

## Voice processing API

Without configuration, the browser records a real audio blob but processing returns deterministic mock data so the complete UI can be demonstrated.

Copy `.env.example` to `.env.local`. The preferred production configuration is a single AWS backend gateway:

```env
VITE_BACKEND_BASE_URL=https://commercial-assistant.example.bakerhughes.com
```

This enables the following same-gateway contracts:

- `GET /api/session` — current user established by the AWS/Entra ID authentication layer;
- `POST /api/voice/sessions` — accepts `{ encoding: "pcm_s16le", sampleRate: 16000, channels: 1 }` and returns a short-lived `websocketUrl` and `sessionId`;
- WebSocket binary frames — mono PCM16 audio; server events use `{ type: "transcript", text, isFinal }`, `{ type: "reconnecting" }`, or `{ type: "error", message }`;
- `POST /api/voice/process` — multipart recording plus the `sessionId` returned by the streaming session, allowing the backend to correlate the final request with AWS Transcribe output;
- `/api/voice/revise`, `/api/entities/resolve`, `/api/cvrs`, `/api/follow-up/draft`, `/api/briefs`, and `/api/briefs/questions` complete the browser-facing gateway surface.

Individual endpoint overrides remain available only for transition/testing:

```env
VITE_VOICE_API_URL=https://api.example.com/voice-notes/process
VITE_SUMMARY_REVISION_API_URL=https://api.example.com/voice-notes/revise
VITE_ENTITY_RESOLUTION_API_URL=https://api.example.com/entities/resolve
VITE_CVR_API_URL=https://api.example.com/cvrs
```

The client then sends `multipart/form-data` with:

- `audio`: captured file (`webm`, `m4a`, or another browser-supported format)
- `mimeType`: browser-reported MIME type
- `size`: blob size in bytes

Expected JSON response:

```json
{
  "transcript": "...",
  "questions": [{ "id": "q1", "topic": "Next steps", "prompt": "..." }],
  "summary": {
    "customer": "...",
    "opportunityId": "...",
    "opportunity": "...",
    "sentiment": "Positive",
    "participants": "...",
    "products": "...",
    "dealSignals": "...",
    "decisionMakers": "...",
    "statedNeeds": "...",
    "timeline": "...",
    "objections": "...",
    "actionItems": "...",
    "blockers": "...",
    "competitors": "...",
    "summary": "..."
  }
}
```

The API boundary lives in `src/services/voiceApi.ts`; remaining simulated operations live in `src/mockApi.ts`.

The revision endpoint accepts `{ "summary": {...}, "instruction": "Timeline is Q4" }` and returns the revised `MeetingSummary`.

Entity resolution receives `{ "summary": {...} }` and returns `EntityResolutionItem[]`. CVR creation receives the finalized summary plus `entityResolution` decisions, so the backend can persist match method, confidence, user action, and resolution timestamps.

## Integration ownership

- The browser first requests a voice session from the authenticated AWS gateway, then sends PCM audio to the returned short-lived WebSocket URL. Long-lived AWS credentials never enter the browser.
- AWS Transcribe, Kafka publication, Bedrock/LangGraph orchestration, Salesforce, MS Graph, SharePoint, Databricks, S3, and Neptune remain behind the backend gateway; the browser does not connect to them directly.
- With no `VITE_BACKEND_BASE_URL`, the app explicitly identifies itself as Mock mode. It records real local audio and emits a deterministic prototype transcript without transmitting audio.
- Entity candidates, confidence, match method, resolution metadata, Bronze chunks, Silver counts, retry state, and audit links require CRM/Databricks APIs. The current UI uses explicitly labelled prototype data for these states.

## Deliberately unavailable until contracts exist

- Voice transcription/AI extraction from the actual recording when no API URL is configured.
- Production live transcript and progressive server-generated summary updates until the AWS endpoint/event contract is deployed (the client contract and UI are implemented).
- Voice answers to follow-up questions and voice input for meeting context.
- Feature 383595: sending the internal email through Outlook (`TBC`).
- Feature 383236: reading meeting and participant data from Outlook (`TBC`).
- Feature 383596: automated reminders (`TBC`, no description or acceptance criteria yet).
- Real AWS Transcribe, Bedrock/LangGraph, CRM entity matching, Deal Machine, Kafka, Databricks Bronze/Silver, Outlook/MS Graph, SharePoint, Neptune, audit, and Entra-backed session integrations.
