# Post-Meeting Voice Capture - User Stories

## Feature
Post-meeting: Capture meeting summary (voice) with minimum necessary information for CRM.

## Story 1 - Voice Note Capture on Mobile
As a sales rep,
I want to record post-meeting notes from my phone,
So that I can capture context immediately after a meeting.

### Acceptance Criteria
1. Given I open the web app on mobile,
When I go to the Notes flow,
Then I can start a voice recording from the browser.
2. Given I have finished speaking,
When I submit the recording,
Then the app sends audio for server-side transcription (via Kafka)

## Story 2 - Generate Transcript and Structured Summary
As a sales rep,
I want my voice note converted into a transcript and structured summary,
So that I do not need to manually format CRM notes.

### Acceptance Criteria
1a. Given my audio is ongoing,
Then I can see a raw transcript captured from audio.
1b. Given I've finished talking (pressed stop button),
Then structured summary is getting updated (see Create Events/Facts/Insights Records in Databricks from Structured Meeting Summary story for details of what needs to be extracted)
2. Given extraction succeeds,
When structured output is shown,
Then it includes minimum fields when available: sentiment, customer, participants, products, deal signals (budget status, decision maker, stated needs, timeline), decision process and approval path, procurement/commercial constraints, incumbent footprint, customer questions/objections, action items, blockers, competitor landscape (including strengths and weaknesses), and explicit next meeting or milestone commitments.
3. Given some details are missing in the note,
When the structured summary is generated,
Then missing fields are not shown rather than fabricated.
4. Given extraction and follow-up are in progress,
When the summary is being filled,
Then I can see the latest structured summary in the UI (potentially by clicking smth like 'unfold' of show summary)
5. Given the latest summary is shown,
When I request audio playback,
Then the agent can voice over the current summary.
6. Given a captured field is incorrect or incomplete,
When I tell the agent what to change in natural language,
Then the agent updates the structured summary and shows the revised result before final save.

## Story 3 - Ask Dynamic Follow-Up Questions for Missing Gaps
As a sales rep,
I want the agent to ask only the most important missing questions,
So that
- I don't accidentally miss to log important information while I still remember it
and at the same time
- I can quickly finalize a useful CRM note and summary (without need to answer 100+ questions)

### Acceptance Criteria
1. Given an initial structured summary exists,
When the agent evaluates completeness,
Then follow-up questions are generated dynamically based on missing data.
2. Given questions are generated,
When they are ordered,
Then priority favors CRM-critical gaps: next steps, market/supplier context, decision process, budget/timeline.
3. Given competitor context is missing,
When follow-up questions are generated,
Then competitor context is prioritized but not guaranteed as a strict deterministic rule.
4. Given follow-up questioning is active,
When the agent continues probing,
Then it asks no more than 5 follow-up questions for that note.

## Story 4 - Avoid Repetitive Questions
As a sales rep,
I want the agent to avoid repeating the same question,
So that the interaction stays concise and useful.

### Acceptance Criteria
1. Given a question has already been asked and answered,
When generating the next question,
Then the agent does not ask the same question text again.
2. Given a topic was just asked,
When generating the next question,
Then the agent should prefer a different missing topic before drilling deeper.
3. Given the rep gives minimal answers (for example, "no" or "not sure"),
When generating the next question,
Then the agent moves to another high-priority uncovered topic.

## Story 5 - Allow Skip and Early Finalization
As a sales rep,
I want to skip low-value questions or finalize early,
So that I can control time spent after a meeting.

### Acceptance Criteria
1. Given a follow-up question is shown,
When I choose Skip,
Then the current question is skipped and the flow continues.
2. Given follow-up questions are still remaining,
When I choose Finalize Now,
Then the app stops probing and moves to the next workflow state for review and processing.
3. Given finalization is reached,
When the next workflow state starts,
Then the flow hands off to feature: "Post-meeting: Create CVR in Deal Machine (SF CRM) from structured meeting summary".

## Story 6 - Create Transcript Chunks and Embeddings in Bronze
As a data and AI platform team,
I want finalized meeting transcripts split into chunks with embeddings,
So that downstream retrieval and search workflows can use transcript-level context.

### Acceptance Criteria
1. Given a transcript is available after capture,
When chunking runs,
Then the transcript is split into deterministic chunks using a defined chunk size and overlap policy.
2. Given transcript chunks are created,
When embedding generation runs,
Then each chunk receives an embedding vector and embedding model metadata.
3. Given chunking and embedding complete successfully,
When persistence runs,
Then chunk records are written to Databricks Bronze with traceable metadata including note_id, chunk_id, chunk_text, chunk_index, embedding_vector, embedding_model, and created_at.
4. Given the same transcript is processed again,
When the pipeline writes to Bronze,
Then duplicate chunk rows are prevented by an idempotent key strategy.
5. Given chunking, embedding, or Bronze write fails,
When processing finishes,
Then the failure is logged with enough context to retry and the user/system receives a failure status.

## Story 7 - Resolve Key Entities Before Downstream Outputs
As a sales operations and CRM data quality team,
I want the system to resolve key entities from meeting outputs before downstream actions,
So that Silver facts are linked correctly, CRM CVRs are created against the right records, and internal communications reference trusted context.

### Acceptance Criteria
1. Given a finalized structured summary exists,
When entity resolution runs,
Then the system attempts to resolve customer/account, opportunity/deal, and meeting participants against CRM master data using deterministic identifiers first (for example email, account ID, opportunity ID) and fuzzy matching only as a fallback.
2. Given an entity has a proposed match at any confidence level,
When the result is presented in the workflow,
Then the user is always shown how it was resolved, including candidate record, match method, and confidence.
3. Given one or more entities are below the confidence threshold,
When agentic processing reaches review,
Then the workflow enters a dedicated "Entity Resolution" sub-state that proactively prompts the user to confirm, change, or remove low-confidence mappings before continuing.
4. Given customer/account resolution is pending,
When the user is prompted in the Entity Resolution sub-state,
Then the user must select exactly one valid CRM customer/account and the workflow cannot continue with no customer selected.
5. Given opportunity or participant resolution is low confidence or not possible,
When the user reviews candidates,
Then the user can either select a valid CRM record or explicitly remove that entity from structured records and keep the original mention as text comment/context.
6. Given entity resolution handling is complete,
When downstream processing runs,
Then there is no unresolved entity branch: Silver events/facts/insights, CVR creation in CRM, and internal email draft generation proceed only with resolved or explicitly removed entities and log the final decision metadata (source system, match method, confidence, user action, and resolution timestamp).

## Story 8 - Create Events/Facts/Insights Records in Databricks from Structured Meeting Summary
As a data and AI platform team,
I want structured meeting summaries transformed into normalized events, facts, and insights records in Databricks,
So that analytics, retrieval, and downstream operational workflows can rely on consistent Silver data.

### Acceptance Criteria
1. Given a structured meeting summary has passed entity resolution,
When the Silver write workflow starts,
Then the system maps summary content into defined events, facts, and insights schemas with required IDs and timestamps.
2. Given transformation runs for event records,
When records are produced,
Then the system explicitly writes these business event types (when available): meeting_held, follow_up_meeting_planned, customer_commitment_made, customer_commitment_missed, poc_or_trial_requested, poc_or_trial_approved, technical_validation_requested, commercial_negotiation_started, procurement_process_started, legal_review_started, budget_approved, budget_declined_or_frozen, scope_expanded, scope_reduced, decision_date_committed, decision_date_moved, competitor_entered_deal, competitor_replaced_in_deal, escalation_raised, and close_plan_confirmed.
3. Given transformation runs for fact records,
When records are produced,
Then the system explicitly writes these fact types (when available): customer_account_reference, opportunity_reference, participant_reference, participant_name, participant_job_title, participant_function_role, participant_seniority_level, stakeholder_influence_level, stakeholder_decision_authority, stakeholder_stance_supporter_or_neutral_or_distractor_or_blocker, economic_buyer_reference, champion_reference, legal_or_procurement_owner_reference, product_mentioned, product_use_case, budget_amount_or_range, budget_owner, budget_cycle_timing, stated_need, success_criteria, buying_timeline_target_date, decision_date_target, action_item, action_item_owner, action_item_due_date, blocker, blocker_owner, customer_question, customer_objection, objection_category, objection_severity, competitor_name, competitor_incumbency_status, competitor_strength, competitor_weakness, competitor_pricing_position, and next_step_commitment.
4. Given transformation runs for insight records,
When records are produced,
Then the system explicitly writes these insight types (when available): win_probability_shift, deal_risk_level, deal_momentum, stakeholder_alignment_score, decision_process_clarity, budget_confidence, timeline_confidence, procurement_risk_level, legal_risk_level, objection_resolution_readiness, competitor_threat_level, white_space_opportunity_score, follow_up_urgency, and recommended_next_best_action.
5. Given event, fact, and insight records are written,
When persistence runs,
Then each record includes note_id, meeting_id (if available), resolved customer/account ID, resolved opportunity ID (or explicit removal marker), resolved participant ID (or explicit removal marker), source trace metadata, and created_at/updated_at.
6. Given required fields for a target record type are missing,
When validation runs before write,
Then the invalid record is rejected with a reason code and the failure is logged without blocking valid records from the same note.
7. Given the same note is processed more than once,
When upsert logic executes,
Then writes are idempotent and do not create duplicate events, facts, or insights.
8. Given at least one Silver write succeeds,
When persistence completes,
Then the workflow emits a processing status summary with counts by record type (created, updated, rejected) and links to audit logs.
9. Given Silver persistence fails for all record types,
When processing finishes,
Then the workflow sets a retryable failure state, preserves diagnostic context, and does not trigger downstream consumers that require Silver completion.